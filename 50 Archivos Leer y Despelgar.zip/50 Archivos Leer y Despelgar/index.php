<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 50 Archivos Leer y Desplegar
    // -------------------------------------------

    // Php permite el manejo de archivos en el disco del Servidor
    // en donde se ejecuta.

    // PHP tiene algunas funciones para crear, leer, actualizar, y
    // editar archivos. A continuación veremos las que son para leer
    // un archivo

    // readfile. Lee un archivo completo y retorna el contenido
    // agregando al final el número de caracteres leidos

    // fopen. Abre un archivo y crear un apuntador al mismo
    // fread. Lee de un archivo una cantidad de caracteres especificos
    // filesize. Devuelve la longitud de un archivo
    // fclose. Cierra un archivo

    // Esta función despliega el contenido del archivo
    // e indica al final cuantos caracteres tiene
    $infoArchivo = readfile("index.php");    
    echo $infoArchivo;
    echo "\n";    
    echo "\n";

    // Este método abre un apuntador a un archivo
    // La "r" indica que se abre de lectura (read)
    $myfile = fopen("index.php", "r") or die("Unable to open file!");

    // Obtiene la longitud del archivo
    $longitudArchivo  = filesize("index.php");
    
    // Despliega la longitud
    echo "Longitud del Archivo index.php :";
    echo $longitudArchivo;
    echo "\n";
    echo "\n";
    
    // Lee todo el archivo
    $contenidoArchivo = fread($myfile,$longitudArchivo);

    // Despliega el contenido del archivo
    echo "Contenido del Archivo:\n";
    echo $contenidoArchivo;
    echo "\n";

    // Cierra el archivo
    fclose($myfile);
?>