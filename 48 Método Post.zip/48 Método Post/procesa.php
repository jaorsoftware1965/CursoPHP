<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 48 Método POST
    // -------------------------------------------
    echo "Archivo Procesa.php... <br>";
    echo "Los datos recibidos:<br>";
    print_r($_POST);

    // Desplegando uno por uno
    echo $_POST["name"]."<br>";
    echo $_POST["email"]."<br>";
    
?>