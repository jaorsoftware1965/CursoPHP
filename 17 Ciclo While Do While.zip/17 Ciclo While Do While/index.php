<?php
    // -------------------------------------
    // Curso de Php
    // Clase 17 Ciclo While y Do While
    // -------------------------------------

    // Los ciclos son bloques de código que se repiten
    // dependiendo de una condición o varias.

    // El Ciclo while ejecuta un bloque de instrucciones
    // dependiendo de si una condición se cumple:

    // Hay 2 formas de usar el ciclo while

     
    // while (condicion es verdad) 
    // {
    //   codigo a ejecutar;
    // }

    // do 
    // {
    //    codigo a ejecutar;
    // } while (condicion es verdad);
    

    // Declaración de variables
    echo "Ciclo While y Do While <br> <br>";
    
    // Inicializamos una variable   
    $x = 1;

    // Indicamos el ciclo while con su condición
    while ($x <= 5) 
    {
       // Desplegamos el valor 
       echo $x."<br>";
       $x++;
    }
    echo "Ya no es verdad que \$x <= 5<br>";
    echo "Valor de \$x al terminar : $x<br>";

    echo "<br>";
    
    // Inicializamos el valor de x
    $x =1 ;

    do 
    {
        echo $x."<br>";        
        $x++;
    } while ($x <= 5);
    echo "Ya no es verdad que \$x <= 5<br>";
    echo "Valor de \$x al terminar : $x<br>";
    echo "<br>";

    echo "Fin del programa ...<br>";

?>
Ejercicio
Usando un ciclo while, despliega en la pantalla la serie de numeros
a) 11,12,13,14,15,16,17,18,19,20
b) 3,2,1,0,-1,-2,-3

