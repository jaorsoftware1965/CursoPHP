<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 26 Parámetros Predeterminados y por Referencia
    // -------------------------------------------

    // Podemos establecer que un parámetro tenga un
    // valor predeterminado, y usarlo si el usuario
    // no lo envía

    // Un parametro por referencia se envia anteponiendo
    // & a la variable
    
    // Declaramos una función
    function fnSuma(int $x=5, int &$y=16) //90
    {        
        // Retornamos
        $x++;//81
        $y++;//91
        fnMultiplicaPor2($y);// 91cuando regresa Y=91
        return $x + $y;
    }
    
    // Función con parametro por referencia
    function fnMultiplicaPor2(int $x) // 91
    {
        // Cambio el Valor de la Variable
        $x = $x * 2; // 182
        echo "x->".$x;
        echo "<br>";
    }

    
    // ----------------------------------------------
    // Programa Principal
    // ----------------------------------------------

    // Titulo Clase
    echo "Parámetros Predeterminados y Por Referencia<br></br>";

    // Ejecuto el Saludo
    $x = 80;
    $y = 90;

    
    echo "---->".fnSuma($x,$y);
    echo "<br>";
    echo "x->$x  y:$y <br>";
    echo "<br>";
    
    // Declaramos variable
    $dato = 5;
    echo "El valor de \$dato es:$dato<br>";

    // Llamamos a la función
    fnMultiplicaPor2($dato);

    // Parametro por referencia
    echo "El valor de \$dato es:$dato<br>";
    echo "<br>";
    
?>