<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Curso de Php</h1>
	<!-- Incluimos codigo PHP dentro del HTML -->
	<?php
		// Comentarios en Php
		echo "Curso de Php"."</br>";
		echo "Clase 02 Sintaxis Inclusion de Código y Ejecución"."</br>";
		echo "El index.php tiene preferencia por el index.html";
		echo "Quiero poner otra cosa"
		// Otro comentario
	?>
	<h2>Clase 02 Sintaxis </h2>
	<!-- asdfasdfadsf -->

	<!-- Creamos objetos Hmtl con Php -->
	<p>Parrafo</p>
	<?php
		// Comentarios en Php
		echo "<p>Esto es un párrafo creado con PHP</p>";
		echo "<p>Hola Mundo<p>";
	?>
</body>
</html>
