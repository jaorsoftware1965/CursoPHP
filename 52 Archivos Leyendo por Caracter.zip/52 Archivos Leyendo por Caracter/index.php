<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 52 Archivos Leyendo Caracter por Caracter
    // -----------------------------------------------

    // En esta clase veremos como leer una archivo caracter por caracter
    // utilizando la función fgetc
    
    // Abrimos el archivo de lectura
    $myfile = fopen("index.php", "r") or die("Unable to open file!");        
    
    // Variable para contar los caracteres
    $cuentaCaracteres = 0;

    // Ciclo que verifica si se ha alcanzado el fin de archivo
    while(!feof($myfile)) 
    {
        
        // Lee el caracter y lo despliega
        $caracter = fgetc($myfile);
        echo $caracter;

        // Incrementa el contador de caracteres
        $cuentaCaracteres++;
    }

    // Cambia de linea
    echo "\n";

    // Despliega el numero de carateres
    echo "Caracteres en el archivo:".$cuentaCaracteres;
    echo "\n";

    # Se cierra el archivo
    fclose($myfile);        
?>