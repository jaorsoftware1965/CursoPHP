<?php
// ---------------------------------
// Curso de Php
// Clase 03 Variables
// ---------------------------------

// Las variables son espacios de memoria que se utilizan para almacenar
// información.

// Se les llama variables porque el valor que almacenan puede variar.

// Las variables en PHP inician su nombre con el simbolo $
    
// El nombre de las variables en PHP deben iniciar con una letra o con 
// un "_" y solo pueden usarse numeros y letras para crearlas.

// Es importante mencionar que Php distingue entre mayúsculas y 
// minúsculas. $x es distinto de $X

// Ejemplos:$apellidoPaterno, $edad, $_nombreAlumno, $EDAD

// A diferencia de otros lenguajes, las variables en PHP no se necesitan
// ser declaradas antes de ser usadas, y el valor que pueden contener
// puede cambiar.

    // Declaración de variables
    echo "Declarando Variables <br> <br>";
    
    // Seccion para las variables
    $nombre    = "Juan Alberto";
    $apellidoM = "OLmos";
    $apellidoP = "Perez";
    $edad      = "45 Años";
    $casado    = True;
    $peso      = 76.500;


    // Desplegamos los valores de las variables
    Echo "Nombre           :".$nombre;
    echo "<br>";
    echo "Apellido Paterno :".$apellidoP."<br>";
    echo "Apellido Materno :".$apellidoM."<br>";
    echo "Edad             :".$edad."<br>";
    echo "Casado           :".$casado."<br>";
    echo "Peso             :".$peso."<br>";
    echo "<br>";

    // Desplegamos los tipo de valores de las variables
    echo VAR_DUMP($nombre)."<br>";
    echo var_dump($apellidoP)."<br>";
    echo var_dump($apellidoM)."<br>";
    echo var_dump($edad)."<br>";
    echo var_dump($casado)."<br>";
    echo var_dump($peso)."<br>";
    echo "<br>";


    // Modificamos los valores de las Variables
    $nombre    = "Pedro";
    $apellidoM = "Perez";
    $apellidoP = "Perez";
    $edad      = 45;
    $casado    = False;
    $peso      = 76.85;


    // Desplegamos los valores de las variables modificadas
    echo "Nombre           :".$nombre."<br>";
    echo "Apellido Paterno :".$apellidoP."<br>";
    echo "Apellido Materno :".$apellidoM."<br>";
    echo "Edad             :".$edad."<br>";
    echo "Casado           :".$casado."<br>";
    echo "Peso             :".$peso."<br>";
    echo "<br>";

    // Servidor Web de PHP si valida existencias de variables    
    //$noExiste = "10";
    echo "Edad             :".$noExiste."<br>";

    // Desplegamos los tipo de valores de las variables
    echo var_dump($nombre)."<br>";
    echo var_dump($apellidoP)."<br>";
    echo var_dump($apellidoM)."<br>";
    echo var_dump($edad)."<br>";
    echo var_dump($casado)."<br>";
    echo var_dump($peso)."<br>";

?>