<?php
    // -------------------------------------
    // Curso de Php
    // Clase 13 Operadores Precedencia
    // -------------------------------------

    // La precedencia de Operadores indica en que orden se
    // deben se ejecutar las operaciones en una expresion:

    // a) 5 + 4 * 2 = ?
    //        9 * 2 = 18
    
    // a) 5 + 4 * 2 =
    //    5 + 8     = 13
    

    // Tabla de Precedencia de Operadores

    // Operadores 
    // clone, new
    // [],()   
    // **
    // ++ -- ~ 
    // instanceof
    // !
    // * / % 
    // + - .   
    // << >> 
    // < <= > >=
    // == != === !== <> <=>
    // &
    // ^
    // | 
    // &&
    // ||
    // ??
    // ?:
    // = += -= *= **= /= .= %= &= |= ^= <<= >>=    asignación
    // and
    // xor lógico
    // or

    // Declaración de variables
    echo "Precedencia de Operadores";
    echo "<br>";echo "<br>";

    echo "a) 5 + 4 * 3 =";
    echo 5 + 4 * 3; // 
    echo "<br>";

    echo "b) (5 + 4) * 3 =";
    echo (5 + 4) * 3;  // 
    echo "<br>";

    echo "c) 5 + 4 * 3 ** 2 ="; 
    echo 5 + 4 * 3 ** 2; // 
    echo "<br>";

    echo "d) 5 + (4 * 3) ** 2 =";
    echo 5 + (4 * 3) ** 2; // 5 + 12 ** 2 = 5 + 144 = 149
    echo "<br>";


    echo "e) 3 * 3 % 5 = ";
    echo 3 * 3 % 5; // 9 % 5 = 4
    echo "<br>";


    // $b=5;
    // echo "f) \$b = $b";
    // echo "<br>";

    // echo "g) \$b += 3 * 5 = ";
    // echo $b += 3 * 5;
    // echo "<br>";

    // $b=5;
    // echo "h) (\$b += 3) * 5 = ";
    // echo ($b += 3) * 5;
    // echo "<br>";
    // echo "\$b = $b";
    // echo "<br>";

    // $b=5;
    // echo "i) (\$b = 3) * 5 = ";
    // echo ($b = 3) * 5;
    // echo "<br>";
    // echo "\$b = $b";
    // echo "<br>";

    



?>
