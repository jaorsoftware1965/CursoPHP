<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 32 Constructores
    // -------------------------------------------

    // Un Constructor en un Método que se ejecuta
    // al momento en que se inicializa o crea un objeto
    // de la clase.

    // El nombre del método es __construct(); y puede
    // tener parámetros al igual que cualquier función
    // vista anteriormente
            
    echo "Clases Constructores</br></br>";

    // Definimos una clase
    class Persona
    {
        // Properties
        public $nombre;
        public $apellido;

        function __construct($nombre="Juan",
                             $apellido="Perez")
        {
            echo "Ejecutando Constructor <br>";
            // asigna el nombre y apellido
            $this->nombre = $nombre;

        }

        function Persona($nombre="Juan",
                         $apellido="Perez")
        {
            echo "Ejecutando Constructor de Persona <br>";
            // asigna el nombre y apellido
            $this->nombre = $nombre;

        }

        // Metodos
        function setNombre($nombre) 
        {
            // coloca el nombre
            $this->nombre   = $nombre;
        }

        function getNombre() 
        {
            // retorna el nombre
            return $this->nombre;
        }
        
        function setApellido($apellido) 
        {
            // coloca el apellido
            $this->apellido = $apellido;
        }

        function getApellido() 
        {
            // retorna el Apellido
            return $this->apellido;
        }
        
    }

    // Creamos un objeto
    $oPersona = new Persona();
    $oPersona = new Persona("Ramirez");
    $oPersona = new Persona("Juan","Ramirez");

    // Desplegamos el objeto
    print_r($oPersona);
    echo "</br>";

    // Colocamos datos
    $oPersona -> nombre   = "Juan";
    $oPersona -> apellido = "Perez";

    print_r($oPersona);
    echo "</br>";
    echo "</br>";

    // Obtenemos cada uno de los elementos del arrego
    foreach ($oPersona as $propiedad => $valor) 
    {
        echo "Propiedad: $propiedad  Valor: $valor <br>";
    }
    echo "</br>";

    // Usando los metodos
    $oPersona->setNombre("Pedro");
    $oPersona->setApellido("Picapiedra");
    print_r($oPersona);
    echo "</br>";

    echo "Nombre   : ".$oPersona->getNombre();
    echo "</br>";     
    echo "Apellido : ".$oPersona->getApellido();
    echo "</br>";

?>