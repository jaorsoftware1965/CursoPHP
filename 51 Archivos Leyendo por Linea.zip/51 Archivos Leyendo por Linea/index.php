<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 51 Archivos II
    // -------------------------------------------

    // En esta clase veremos como leer una archivo linea por linea
    // utilizando la función fgets
    // Se considera una linea hasta donde se encuentra el return o enter

    // Es posible verificar si se ha alcanzado el final de un archivo
    // al irlo leyendo, utilizando la función feof(). (End Of File)

    // Abrimos el archivo de lectura
    $myfile = fopen("index.php", "r") or die("Unable to open file!");
    
    // Leemos una linea
    $linea = fgets($myfile);

    // Desplegamos la liena
    echo "Linea leida:".$linea;
    echo "\n";

    // Se cierra el archivo
    fclose($myfile);

    // Ahora desplegaremos todo el archivo pero leyendo linea por linea

    // Abrimos el archivo de lectura
    $myfile = fopen("index.php", "r") or die("Unable to open file!");

    // Variable para contar las lineas
    $cuentaLineas = 1;

    // Ciclo que verifica si se ha alcanzado el fin de archivo
    while(!feof($myfile)) 
    {
        // Formatea el contador de lineas para agregar 0's a la izquierda
        $numLinea = substr(str_repeat(0, 5).$cuentaLineas, - 5);

        // Lee la linea y la despliega
        $linea =fgets($myfile);

        // Despliega
        echo $numLinea.":".$linea;

        // Incrementa el contador de lineas
        $cuentaLineas++;
    }

    # Se cierra el archivo
    fclose($myfile);        
?>