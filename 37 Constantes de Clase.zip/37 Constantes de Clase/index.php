<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 37 Constantes de Clase
    // -------------------------------------------

    // Las constantes no se pueden cambiar una vez que se declara.
    // Las constantes de clase pueden ser útiles si necesita definir 
    // algunos datos constantes dentro de una clase.
    
    // Una constante de clase se declara dentro de una clase con la 
    // palabra clave const.

    // Las constantes de clase distinguen entre mayúsculas y minúsculas. 
    // Sin embargo, se recomienda nombrar las constantes en mayúsculas.

    // Podemos acceder a una constante desde fuera de la clase usando 
    // el nombre de la clase seguido del operador de resolución de alcance (::) 
    // seguido del nombre de la constante.

    // Para acceder a una constante de clase, dentro de la misma clase
    // se debe hacer uso de la palabra reservada "self"


    // Mensaje de la Clase    
    echo "Clase 37 Constantes de Clase\n\n";

    // Definimos una Claase
    class Alumnos 
    {
        // Definimos constantes de Clase
        const UNIVERSIDAD = "UNAM";
        const SEMESTRE = "5o";

        // Constructor
        function __construct ()
        {
           // Desplegamos UNIVERSIDAD y SEMESTRE
           echo "Registrando Alumno en:\n";
           echo "Universidad:".self::UNIVERSIDAD."\n";
           echo "Semestre   :".self::SEMESTRE."\n";
        }

        
    }
    
    // Desplegamos la constante desde el nombre de la Clase
    echo "Universidad:". Alumnos::UNIVERSIDAD;
    
    // Cambio de linea
    echo "\n\n";

    // Creamos un alumno
    $alumno = new Alumnos();

  


    
?>