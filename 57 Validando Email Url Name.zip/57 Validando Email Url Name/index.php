<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 57 Validando Email Url Name
    // -----------------------------------------------

    // Validando el nombre obtenido del arreglo POST
    //$name = test_input($_POST["name"]);

    // Función que evalua los datos
    function test_input($data) 
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
     
    //$name = test_input($_POST["name"]);
    $name =test_input("Juan Perez");

    // Verifica si el campo de nombre solo contiene letras, guiones, apóstrofes y 
    // espacios en blanco. 
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) 
    {
        // Mensaje de Error
        echo "Error. El nombre es incorrecto:".$name."\n";
    }  
    else
    {
        // Mensaje de Extio
        echo "Exito. El nombre es correcto  :".$name."\n";
    } 
    
    // Validando el email
    //$email = test_input($_POST["email"]);
    $email = test_input("jaorsoftware1965@gmail.com");
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
    {
        echo "Error. El email es incorrecto:".$email."\n";
    }
    else
    {
        echo "Exito. El email es correcto  :".$email."\n";
    }

    // Validando la url
    //$url = test_input($_POST["website"]);
    $url = test_input("www.google.com");
    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$url)) 
    {
        // Mensaje de Error
        echo "Error. La URL es incorrecta:".$url;
    }
    else
    {
        // Mensaje de Error
        echo "Exito. La URL es correcta  :".$url;
    }
?>