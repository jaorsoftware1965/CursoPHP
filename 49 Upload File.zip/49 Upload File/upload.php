<?php
    // ------------------------------------------------
    // Curso de Php
    // Clase 49 Upload File
    // ------------------------------------------------
    
    // Variable para indicar el directorio y el archivo
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

    // Variable para saber si se cargó correctamente
    $uploadOk = 1;

    // Obtenemos información del archivo
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    // Verificamos que efectivamente se haya seleccionado un archivo
    if (isset($_POST["submit"])) 
    {
        // Verificamos que sea una imagen el archivo a subir
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if ($check !== false) 
        {
            // Si es una imagen
            echo "Archivo es una imagen - " . $check["mime"] . ".";
            $uploadOk = 1;
        } 
        else 
        {
            // No es una imagen
            echo "Error. Archivo no es una imagen.";
            $uploadOk = 0;
        }
    }    

    // Verificamos que exista
    if (file_exists($target_file)) 
    {
        echo "Error. El archivo ya existe.";
        $uploadOk = 0;
    }
    
    // Verificamos el tamaño
    if ($_FILES["fileToUpload"]["size"] > 500000) 
    {
        echo "Error. El archivo es demasiado grande.";
        $uploadOk = 0;
    }
    
    // Verificamos el tipo del archivo, con los permitidos
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) 
    {
        echo "Error. Únicamente JPG, JPEG, PNG y GIF son permitidos.";
        $uploadOk = 0;
    }
    
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) 
    {
        // Mensaje de que el archivo no será cargado
        echo "Error. El Archivo no será cargado.";       
    } 
    else 
    {
        // Intentamos mover y verificamos
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
        {
            // Si se pudo subir
            echo "Éxito. El archivo ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " ha sido cargado.";
        } 
        else 
        {
            // No se pudo subir
            echo "Error. Ocurrió un error al cargar el archivo.";
        }
    }
?>