<?php
    // -------------------------------------
    // Curso de Php
    // Clase 23 Ordenando Arreglos
    // -------------------------------------

    // El Ordenamiento de los arreglos en PHP

    //   sort. Ordena Ascendente   
    //  rsort. Ordena Descendente

    //  asort. Ordena Ascendente por  Valor
    //  ksort. Ordena Ascendente por  Llave 
    // arsort. Ordena Descendente por Valor
    // krsort. Ordena Descendente por Llave
    
    // Declaración de variables
    echo "Ordenando Arreglos <br> <br>";
    
    // Definimos un arreglo de colores
    $colores = array("rojo", 
                     "verde", 
                     "azul", 
                     "amarillo");
    
    // Ordenamos Ascendente el Arreglo
    sort($colores);

    // Obtenemos cada uno de los elementos del arrego
    echo "Colores ordenados Ascendentemente <br>";
    foreach ($colores as $color) 
    {
        echo "El color es: $color <br>";
    }

    // Dejamos una linea en blanco
    echo "<br>";
 
    // Ordenamos el Arreglo Descendente
    rsort($colores);

    // Obtenemos cada uno de los elementos del arrego
    echo "Colores ordenados Descendentemente <br>";
    foreach ($colores as $color) 
    {
        echo "El color es: $color <br>";
    }

    // Dejamos una linea en blanco
    echo "<br>";


    // Declaramos un arreglo asociativo   
    $personas = array("Benito"  => "75", 
                      "Ana"    => "37", 
                      "Jose"   => "43");

    // Ordenamos de acuerdo al valor
    asort($personas);

    // Ciclo para cada una de las edades
    echo "Lista de Nombres Ordenados Ascendentes por Edad <br>";
    foreach($personas as $nombre => $edad) 
    {
        echo "$nombre = $edad<br>";
    }
    
    // Dejamos una linea en blanco
    echo "<br>";


    // Ordenamos de acuerdo al valor
    ksort($personas);

    // Ciclo para cada una de las edades
    echo "Lista de Nombres Ordenados Ascendente por Nombre <br>";
    foreach($personas as $nombre => $edad) 
    {
        echo "$nombre = $edad<br>";
    }
    // Dejamos una linea en blanco
    echo "<br>";

    // Ordenamos de acuerdo al valor
    arsort($personas);

    // Ciclo para cada una de las edades
    echo "Lista de Nombres Ordenados Descendentes por Edad <br>";
    foreach($personas as $nombre => $edad) 
    {
        echo "$nombre = $edad<br>";
    } 
    // Dejamos una linea en blanco
    echo "<br>";


    // Ordenamos de acuerdo al valor
    krsort($personas);

    // Ciclo para cada una de las edades
    echo "Lista de Nombres Ordenados Descendente por Nombre <br>";
    foreach($personas as $nombre => $edad) 
    {
        echo "$nombre = $edad<br>";
    }
    // Dejamos una linea en blanco
    echo "<br>";

    // Ordenar el color por llave
    ksort($colores);
    print_r($colores);
    echo "</br>";
    asort($colores);
    print_r($colores);

?>    










