<?php
    // -------------------------------------
    // Curso de Php
    // Clase 22 Arreglos Multidimensionales
    // -------------------------------------
                
    // Un arreglo multidimensional es un arreglo de 
    // arreglos

    // Declaración de variables
    echo "Arreglos Multidimensionales </br></br>";

    // Declaramos una arreglo de arreglos
    $matriz = array 
    (   //c->  0  1  2  3  4  
        array(20,31,22)    ,   // renglon 0 
        array(70,41,32,43) ,   // renglon 1
        array(75,51,42)    ,   // renglon 2
        array(80,81,72,35,48)  // renglon 3
    );
    //echo "Imprimo la Matriz con su estructura:</br>";
    //print_r($matriz);

    
    echo "<br>";
    echo "<br>";

    // Desplegando cada dato
    //           R  C
    //echo $matriz[3][09]."<br>";
    // echo $matriz[1][2]."<br>";
    // echo $matriz[2][1]."<br>";
    // echo $matriz[3][2]."<br>";
    // echo $matriz[2][2]."<br>";
    // echo "</br>";

    //Ciclo para desplegar la matriz
    // echo "Imprimiendo la Matriz por indices <br>";
    // for ($ren=0; $ren < count($matriz); $ren++)
    // {
    //     for ($col=0; $col < count($matriz[$ren]);$col++)
    //     {
    //         // Desplegamos valor del elemento
    //         echo $matriz[$ren][$col]." ";
    //     }
    //     echo "</br>";
    // }

    //print_r($matriz);
    //echo "</br></br>";

    // Obtenemos los renglones
    echo "Imprimiendo la Matriz con foreach <br>";
    foreach ($matriz as $renglon) 
    {
        // Obtenemos cada uno de los elementos del arrego
        foreach ($renglon as $dato) 
        {
            echo $dato." ";
            echo "</br>";
        }
        echo "</br>";
        
    } 

    //print_r($matriz);
    echo "</br></br>";

    // // Arreglo de Empleados
    // $empleados = array(
    //                     array(
    //                         'id' => 5698,
    //                         'nombre' => 'Pedro',
    //                         'apellido' => 'Perez',
    //                     ),
    //                     array(
    //                         'id' => 4767,
    //                         'nombre' => 'Benito',
    //                         'apellido' => 'Bodoque',
    //                     ),
    //                     array(
    //                         'id' => 3809,
    //                         'nombre' => 'Jose',
    //                         'apellido' => 'Duarte',
    //                     )
    //                 );

    // //print_r($empleados);
    // // Obtenemos los renglones
    // foreach ($empleados as $renglon) 
    // {
    //     // Obtenemos cada uno de los elementos del arrego
    //     foreach ($renglon as $dato) 
    //     {
    //         echo $dato." ";
    //     }
    //     echo "</br>";
    // } 
?>