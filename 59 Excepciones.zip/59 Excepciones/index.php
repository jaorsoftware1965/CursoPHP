<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 59 Excepciones
    // -----------------------------------------------

    // ¿Qué es una excepción?
    // Una excepción es un objeto que describe un error o un comportamiento 
    // inesperado de un script PHP.
    // Muchas funciones y clases de PHP lanzan excepciones.
    // Las funciones y clases definidas por el usuario también pueden generar 
    // excepciones.

    // Las excepciones son una buena manera de detener una función cuando se 
    // encuentra con datos que no puede usar.
    
    // Lanzando una excepción
    // La instrucción throw permite que una función o método definido por 
    // el usuario lance una excepción. Cuando se lanza una excepción, el código 
    // que le sigue no se ejecutará.
    // Si no se detecta una excepción, se producirá un error fatal con un mensaje
    // de "Excepción no detectada".

    // Intentemos lanzar una excepción sin atraparla:

    // Función para dividir 2 números
    function fnDivide($dividendo, $divisor) 
    {
        // Verifica si el divisor es 0
        if ($divisor == 0) 
        {
            // Lanza la excepción si el divisor es 0
            throw new Exception("División por Cero",165);
        }
        // Realiza y Retorna la división
        return $dividendo / $divisor;
    }      

    // Ejecuta la División sin capturar la excepción
    // echo fnDivide(5, 0);

    // Captura el código
    try 
    {
        // Ejecuta la División
        echo "Resultado:".fnDivide(5, 0);
        echo "\n";
    } 

    // Captura la Excepción
    catch(Exception $e) 
    {
        // Despliega el valor de $e
        echo "Se ha detectado un error:\n";
        echo "Mensaje : ".$e->getMessage();
        echo "\n";
        echo "Codigo  : ".$e->getCode();
        echo "\n";
        echo "Archivo : ".$e->getFile();
        echo "\n";
        echo "Linea   : ".$e->getLine();
        echo "\n\n";
    }
    finally 
    {
        // Continua el Programa
        echo "Continua el Programa ...\n";
    }

    // Mensaje de Finalización
    echo "Programa terminado ...\n";
?>