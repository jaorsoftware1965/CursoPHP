<?php
// --------------
// Funciones php
// --------------
echo "Incluyendo el archivo <br>";

function fnColorTexto($color)
{
	// Crea el objeto font con el color
	echo "<font color='$color'>";
}

function fnCerrarFont()
{
	// Crea el objeto font con el color
	echo "</font>";
}

// Función para sumar 2 numeros
function fnSumar(int $x, int $y)
{
    // Retorna la suma
    return $x + $y;
}

echo "Se ha Terminado de incluir el archivo<br>";
echo "<br>"
?>