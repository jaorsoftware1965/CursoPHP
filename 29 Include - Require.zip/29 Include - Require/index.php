<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 29 Include y Require
    // -------------------------------------------

    // Las funciones include y require nos permiten
    // incluir archivos externos a nuestro programa

    // La diferencia entre ellas es que si require 
    // falla, generará un error Fatal y detendrá la 
    // ejecución.

    // Si include falla, se genera un Warning y 
    // la ejecución no se detiene.

    // NOTA. Solo un error FATAL detiene un programa php
    
    echo "Include y Require</br></br>";

    // Incluye el archivo
    //include "funciones2.php";
    require "funciones.php";

    // Creo font con color rojo
    fnColorTexto("green");

    // Final
    echo "El Programa se ha incluido";    
    echo "</br>";

    // Suma 2 numeros
    echo "La suma es :".fnSumar(15,34);
    echo "</br>";

    // Cierro el Font
    fnCerrarFont();

    // Final
    echo "El Programa ha finalizado";

?>
