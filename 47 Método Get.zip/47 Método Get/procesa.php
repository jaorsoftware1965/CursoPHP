<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 47 Método GET
    // -------------------------------------------
    echo "Archivo Procesa.php... <br>";
    echo "Los datos recibidos:<br>";
    print_r($_GET);

    // Desplegando uno por uno
    echo $_GET["name"]."<br>";
    echo $_GET["email"]."<br>";
    
?>