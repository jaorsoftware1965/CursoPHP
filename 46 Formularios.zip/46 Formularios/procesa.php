<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 46 Formulario
    // -------------------------------------------
    echo "Archivo Procesa.php... <br>";
    
    
?>