<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 53 Archivos Creando
    // -----------------------------------------------

    // En esta clase veremos como crear un archivo y escribir
    // información en el.

    // Para crearlo se usa el parámetro "w" con la función openfile    
    // Para escribir en el archivo, se utiliza la funcion fwrite
    // Si el archivo ya existe, se sobreescribe en el 

    // Para borrar un archivo, se utiliza la función unlink

    // Se abre el archivo para escritura
    $myfile = fopen("test.txt", "w") or die("Unable to open file!");

    // Linea a grabar en el archivo
    $lineaGrabar = "En un canal de Youtube, del cual ....\n";

    // Grabamos en el archivo
    fwrite($myfile, $lineaGrabar);

    // Segunda linea
    $lineaGrabar = "Había un ingenioso programador que ....\n";
    
    // Graba la linea
    fwrite($myfile, $lineaGrabar);

    // Cierra elarchivo
    fclose($myfile);  
    
    // Se abre el archivo para agregar al final
    $myfile = fopen("test.txt", "a") or die("Unable to open file!");

    // Linea a grabar en el archivo
    $lineaGrabar = "Este es un texto agregado al final\n";

    // Grabamos en el archivo
    fwrite($myfile, $lineaGrabar);

    // Cierra elarchivo
    fclose($myfile); 
    
    // Borramos el archivo al final
    unlink("test.txt");
?>