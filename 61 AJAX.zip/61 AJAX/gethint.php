<?php
// Arreglo con Nombre
$a[] = "Anna";
$a[] = "Brittany";
$a[] = "Cinderella";
$a[] = "Diana";
$a[] = "Eva";
$a[] = "Fiona";
$a[] = "Gunda";
$a[] = "Hege";
$a[] = "Inga";
$a[] = "Johanna";
$a[] = "Kitty";
$a[] = "Linda";
$a[] = "Nina";
$a[] = "Ophelia";
$a[] = "Petunia";
$a[] = "Amanda";
$a[] = "Raquel";
$a[] = "Cindy";
$a[] = "Doris";
$a[] = "Eve";
$a[] = "Evita";
$a[] = "Sunniva";
$a[] = "Tove";
$a[] = "Unni";
$a[] = "Violet";
$a[] = "Liza";
$a[] = "Elizabeth";
$a[] = "Ellen";
$a[] = "Wenche";
$a[] = "Vicky";

// Obtiene el parametro desde la URL
$q = $_REQUEST["q"];

// Inicializa en blanco la variable
$hint = "";

// Verifica si no está vacío
if ($q !== "") 
{
    // Convierte a Mayúsculas
    $q = strtolower($q);

    // Obtiene la longitud
    $len=strlen($q);

    // Ciclo para buscar en cada uno de ellos 
    foreach($a as $name) 
    {
        // Verifica si la encuentra
        if (stristr($q, substr($name, 0, $len))) 
        {
            // Verifica si es vacío
            if ($hint === "") 
            {
                // coloca el nombre si es el primero
                $hint = $name;
            } 
            else 
            {
                // Agrega una coma si no es el primero
                $hint .= ", $name";
            }
        }
  }
}

// Coloca "no sugerencias" if no se encontraron hint
echo $hint === "" ? "no sugerencias" : $hint;
?>