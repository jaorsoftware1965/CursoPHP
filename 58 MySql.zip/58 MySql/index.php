<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 58 MySql
    // -----------------------------------------------

    // Datos para conexión a MySql
    $servername = "localhost";
    $username   = "root";
    $password   = "admin";

    // Create connection
    $conn = new mysqli($servername, $username, $password);

    // Check connection
    if ($conn->connect_error) 
    {
        die("La Conexión ha fallado: " . $conn->connect_error);
    }
    
    // Mensaje de Éxito
    echo "La conexión se ha conseguido\n\n";

    // Prepara Query para Consulta de Bases de Datos
    $sql = "SHOW DATABASES";

    // Ejecuta la Consulta
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
        // Lista de las Bases de Datos
        echo "La lista de Base de Datos:\n";

        // output data of each row
        while ($row = $result->fetch_assoc()) 
        {
            // Despliega la Base de Datos
            echo $row["Database"]. "\n";
        }
    } 
    else 
    {
        // Sin resultados
        echo "Sin resultados";
    }

    // Cierra la Conexión
    $conn->close();
?>