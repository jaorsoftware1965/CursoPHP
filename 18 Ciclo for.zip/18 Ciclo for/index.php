<?php
    // -------------------------------------
    // Curso de Php
    // Clase 18 Ciclo for 
    // -------------------------------------

    // El ciclo for nos permite realizar un ciclo
    // una cantidad de veces establecida

    // for (init counter; test counter; increment counter) 
    // {
    //   code to be executed for each iteration;
    // }

    // Mensaje de
    echo "Ciclo for <br> <br>";
    
    // Ciclo for básico
    for ($x = 1; $x <= 10; $x++) 
    {
        echo $x."<br>";
    }
    echo "Valor de \$x al terminar : $x<br>";
    echo "<br>";

    // Ciclo con incremento de 3
    for ($x = 1; $x <= 10; $x+=3) 
    {
        echo $x."<br>";
    }
    echo "Valor de \$x al terminar : $x<br>";
    echo "<br>";

    // Ciclo decreciente
    for ($x = 10; $x >0; $x--) 
    {
        echo $x."<br>";
    }
    echo "Valor de \$x al terminar : $x<br>";
    echo "<br>";    

    // Ciclo decrementando 2
    for ($x = 10; $x >0; $x-=3) 
    {
        echo $x."<br>";
    }
    echo "Valor de \$x al terminar : $x<br>";
    echo "<br>";  
?>