<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 40 Métodos Estáticos
    // -------------------------------------------

    // Hasta ahora, los métodos que se han definido en las clases
    // para poder utilizarlos se necesita crear un objeto de la clase
    // y desde el, ejecutarlo.

    // Los métodos estáticos; están asociados a la Clase; y no es
    // necesario crear una instancia u objeto de la clase para poder
    // utilizarlos

    // Para declarar un método static, se utiliza la palabra reservada
    // "static"

    // Para llamar al método estático, se coloca el nombre de la clase
    // seguida de "::" y posteriormente el nombre del método estático

    // Es tambien posible llamar a un método estático desde el interior
    // de una clase en el método constructor, usando la palabra reservada
    // "self", seguida de el nombre del método estático

    // Es posible tambien especificar que el método estático solo sea 
    // llamado desde el interior de una clase; si se establece protected
    // Entonces ya no es posible llamarlo desde la clase
    
    // Mensaje de la Clase    
    echo "Clase 40 Métodos Estáticos\n\n";

    // Clase Padre
    class Autos
    {
        // Definimos un Método estático
        // Función que retorna el origen de una marca
        public static function getOrigen($marca) : string
        {
            // Variable de resultado
            $resultado;

            switch ($marca) 
            {
                case "Volkswagen":
                    $resultado = "Alemania";
                    break;
                case "Ford":
                    $resultado = "USA";
                    break;
                case "Nissan":
                    $resultado = "Japón";
                    break;
                default:
                    $resultado = "No identificado";
                    break;    
            }
            
            // Devuelve el resultado
            return $resultado;
        }    

        public function  __construct($marca)
        {
            //Llamo al método estático
            echo "Origen de la Marca:$marca:";
            echo self::getOrigen($marca);
            echo "\n";
        }
    }
      
    // Llamamos al Método estático sin crear un objeto o instancia
    echo "Origen:".Autos::getOrigen("Volkswagen");  
    echo "\n";
    echo "Origen:".Autos::getOrigen("Ford");  
    echo "\n";
    echo "Origen:".Autos::getOrigen("Nissan");  
    echo "\n";
    echo "Origen:".Autos::getOrigen("Audi");  
    echo "\n";
    echo "\n";

    // Creamos un objeto
    $oAuto = new Autos("Ford");

        // Creamos otra Clase
        class otraClase 
        {
            // Funcion Mensaje
            public function message() 
            {
                // Llamando a la función estática desde otra clase
                echo "Marca desde otra clase:".Autos::getOrigen("Ford");
                echo "\n";
            }
        }
    
        // Creamos un objeto de la otra clase
        $x = new otraClase();
        
        // Ejecutamos el método
        $x->message();
    
        // Clase Padre
        class Dominio 
        {
            // función estática protegida
            // solo puede ejecutarse desde la clase heredada
            protected static function getWebsiteName() 
            {
                // Retorna el sitio Web
                return "google.com\n";
            }
          }
        
        // Clase hija
        class DominioW3 extends Dominio 
        {
            // Propiedad
            public $websiteName;
    
            // Constructor
            public function __construct() 
            {
                // Llama a función estática
                $this->websiteName = parent::getWebsiteName();
            }
        }
      
    // crea un Objeto del Dominio
    $xDominio = new DominioW3;
    echo $xDominio -> websiteName;

    // No se puede llamar desde la Clase al Método estático si es protegido
    // DominioW3::getWebsiteName();
    
?>