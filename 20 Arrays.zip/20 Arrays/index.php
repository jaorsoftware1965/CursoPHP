<?php
    // -------------------------------------
    // Curso de Php
    // Clase 20 Arreglos
    // -------------------------------------

    // Los arreglos son variables que pueden tener mas de un dato
    // y a los cuales se les accede por un indice o por una llave.
    
    // En esta clase veremos los arreglos por indice.
    // Los Arreglos por indice siempre inicia en 0

    // Mensaje de la Clase
    echo "Arreglos <br> <br>";
    
    // Arreglo de Autos
    $autos = array("Volvo","Chevrolet","Ford");

    // Desplegando los autos    
    echo "Lista de autos en el arreglo <br>";
    echo $autos[0] . "<br>";
    echo $autos[1] . "<br>";
    echo $autos[2] . "<br>";
    echo "<br>";
    $autos[0] = "Vw";
    $autos[3] = "otros";
    
    print_r($autos);
    echo "<br>";

    // Para saber la longitud del arreglo se usa la función count
    echo "Cuantos autos hay en el arreglo:";
    echo count($autos);
    echo "<br>";

    // Ciclo para imprimir los elementos del arreglo
    for($x = 0; $x < count($autos); $x++) 
    {
       echo $autos[$x];
       echo "<br>";
    }
    echo "<br>";

    // Lenguajes de Programación
    $lenguajes[0]="Php";
    $lenguajes[1]="JavaScript";
    $lenguajes[2]="Java";
    $lenguajes[3]="C#";

    // Desplegamos los valores
    echo "Lenguajes:";
    echo "<br>";
    echo $lenguajes[0] . "<br>";
    echo $lenguajes[1] . "<br>";
    echo $lenguajes[2] . "<br>";
    echo $lenguajes[3] . "<br>";
    //echo $lenguajes[3] . "<br>";
    //echo $lenguajes[4] . "<br>";
    echo "<br>";

    // Longitud del arreglo de Lenguajes
    echo "Cuantos lenguajes hay en el arreglo:";
    echo count($lenguajes);
    echo "<br>";

    // Ciclo para imprimir los elementos del arreglo
    for($x = 0; $x < count($lenguajes); $x++) 
    {
       echo $lenguajes[$x];
       echo "<br>";
    }
    echo "<br>";


    // // Arreglos Asociativos
    // //             llave    => valor
    // $Datos = array("Benito Juarez"  => 45, 
    //                "Presidencia"    => 3.1416, 
    //                "Sol"            => "Toyota");

    
    // $Datos['Maria'] = 35;
    // $Datos['Beto']  = 37;
    // $Datos['Elena'] = 43;
    // $Datos[2]       = "El 2";
    // $Datos[10]="20 de Noviembre";

    // echo "-----El arreglo asociativo modificado.----</br>";
    // print_r($Datos);
    // echo "<br>";
    // echo "<br>";
    
    // // Desplegando los valores en el arreglo
    // echo "Los Datos en el Arreglo <br>";
    // echo $Datos['Pedro']."<br>";
    // echo $Datos['Maria']."<br>";
    // echo $Datos[2]."<br>";

    // // Longitud del arreglo de Lenguajes
    // echo "Cuantas Edades:";
    // echo count($Datos);
    // echo "<br>";

    // print_r($Datos);
    // echo "<br>";

    // // Ciclo para imprimir los elementos del arreglo
    // for($x = 0; $x < count($Datos); $x++) 
    // {
    //    echo $Datos[$x];
    //    echo "<br>";
    // }
    // echo "<br>";
?>