<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 54 Cookies
    // -----------------------------------------------

    // ¿Qué es una cookie?
    // Una cookie se utiliza a menudo para identificar a un usuario. 
    // Una cookie es un pequeño archivo que el servidor incrusta en la 
    // computadora del usuario. 
    // Cada vez que la misma computadora solicite una página con un navegador, 
    // también enviará la cookie. 
    // Con PHP, puede crear y recuperar valores de cookies.

    // La función para crear una cookie es: setcookie()

    // Establece la cookie
    $cookie_name = "user";
    $cookie_value = "John Doe";

    // Coloca la cookie estableciendo que exista durante 30 dia
    // 86400 = 1 day
    // Primero se prueba el programa sin dar de alta la cookie
    setcookie($cookie_name, // Nombre de la cookie
              $cookie_value,// Valor  de la cookie
              time() + (86400 * 30), // Hasta cuando expira; en 30 dias
               "/");       // Ruta de la Cookie
   
    // Verifica si existe la cookie
    if ( !isset($_COOKIE[$cookie_name])) 
    {
        // No existe
        echo "Cookie con el nombre '" . $cookie_name . "' no existe !";
    } 
    else 
    {
        echo "Cookie : [" . $cookie_name . "] existe !<br>";
        echo "Valor  : [" . $_COOKIE[$cookie_name]."]";
    }    
?>