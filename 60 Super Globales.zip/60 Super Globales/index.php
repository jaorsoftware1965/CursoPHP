<?php
    session_start();
    // -----------------------------------------------
    // Curso de Php
    // Clase 60 SuperGlobales
    // -----------------------------------------------

    // Php predefine variables llamadas SuperGlobales, las cuales utiliza
    // para diferentes propositos.
    // Algunas de ellas ya las hemos visto en temas previos.

    // Acá esta la lista total de ellas:
    // $GLOBALS
    // $_SERVER
    // $_REQUEST
    // $_POST
    // $_GET
    // $_FILES
    // $_ENV
    // $_COOKIE
    // $_SESSION

    // A continuación ejemplos de cada una de ellas

    // --------------------------------------------
    // $GLOBALS
    // Arreglo con las variables globales definidas
    // --------------------------------------------

    // Define 2 variables
    $x = 75;
    $y = 25;
 
    // Función para sumar variables globales
    function addition() 
    {
        // Suma x + y y lo deposita en z
        $GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
    }
 
    // Llama a la función
    addition();

    // Despliega el valor de z
    echo "El valor de la variable global z:".$z; 
    echo "\n";
    echo "\n";


    // --------------------------------------
    // $_SERVER
    // Variables con información del Servidor
    // --------------------------------------
    
    echo "PHP_SELF:\n";
    //echo $_SERVER['PHP_SELF'];    
    echo "\n";

    echo "SERVER_NAME:\n";
    //echo $_SERVER['SERVER_NAME'];
    echo "\n";

    echo "HTTP_HOST:\n";
    //echo $_SERVER['HTTP_HOST'];
    echo "\n";

    echo "HTTP_REFERER:\n";
    //echo $_SERVER['HTTP_REFERER'];
    echo "\n";

    echo "HTTP_USER_AGENT:";
    //echo $_SERVER['HTTP_USER_AGENT'];
    echo "\n";

    echo "SCRIPT_NAME:";
    echo $_SERVER['SCRIPT_NAME'];
    echo "\n";
    echo "\n";

    
    // ---------------------------
    // $_REQUEST
    // ---------------------------
    // Almacena las variables generadas en un Submit

    // Despliega el Arreglo
    echo "REQUEST:\n";
    print_r($_REQUEST);
    echo "\n";
    echo "\n";


    // -------------------------------------------------------------
    // $_POST
    // Almacena las variables generadas en un Submit con método POST
    // -------------------------------------------------------------
    
    // Despliega el Arreglo
    echo "POST:\n";
    print_r($_POST);
    echo "\n";
    echo "\n";

    // -------------------------------------------------------------
    // $_GET
    // Almacena las variables generadas en un Submit con método GET
    // -------------------------------------------------------------
    
    // Despliega el Arreglo
    echo "GET:\n";
    print_r($_GET);
    echo "\n";
    echo "\n";

    
    // -------------------------------------------------------------
    // $_FILES
    // Almacena los archivos utilizados
    // -------------------------------------------------------------
    
    // Despliega el Arreglo
    echo "FILES:\n";
    print_r($_FILES);
    echo "\n";
    echo "\n";

    // -------------------------------------------------------------
    // $_ENV
    // Almacena las variables de ambiente
    // -------------------------------------------------------------
    
    // Despliega el Arreglo
    echo "ENV:\n";
    print_r($_ENV);
    echo "\n";
    echo "\n";

    // -------------------------------------------------------------
    // $_COOKIE
    // Almacena las cookies encontradas
    // -------------------------------------------------------------
    
    // Despliega el Arreglo
    echo "COOKIE:\n";
    print_r($_COOKIE);
    echo "\n";
    echo "\n";

    // -------------------------------------------------------------
    // $_SESSION
    // Almacena las variables generadas en una sesión
    // -------------------------------------------------------------
    
    // Despliega el Arreglo
    echo "SESION:\n";
    print_r($_SESSION);
    echo "\n";
    echo "\n";

?>