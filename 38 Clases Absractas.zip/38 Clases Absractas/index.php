<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 38 Clases Abstractas
    // -------------------------------------------

    // Las clases y métodos abstractos son cuando la clase principal 
    // tiene un método con nombre, pero necesita su(s) clase(s) 
    // secundaria(s) para completar las tareas.

    // Una clase abstracta es una clase que contiene al menos un 
    // método abstracto. 
    // Un método abstracto es un método que se declara, pero no se 
    // implementa en el código.

    // Una clase o método abstracto se define con la palabra clave abstract:
    // Ejemplo

    // abstract class test
    // {
    //     abstract public function metodo1();
    //     abstract public function metodo2($x, $y);
    //     abstract public function metodo3(): string;
    // }
    
    // En el ejemplo anterior la Clase test es abstracta.
    // Todos su métodos son abstractos; es decir; que no tienen contenido; solo
    // están definidos. Con que solo uno fuera abstracto es suficiente para ser
    // llamada clase abstracta.

    // Cuando defines una clase hija de una Clase abstracta; obligatoriamente tienes
    // que redefinir las clase abstractas indicadas; o se te marcará un error.

    // Mensaje de la Clase    
    echo "Clase 38 Clases Abstractas\n\n";

    // Clase Padre
    abstract class Auto 
    {
        // Propiedad de la Clase
        private   $año;
        protected $modelo;

        // Constructor
        public function __construct($name) 
        {
            // Asigna el Nombre
            $this->name   = $name;
            $this->modelo = "2022";
        }

        // Método Abstracto; deberá ser redefinido obligatoriamente en clases hijas
        abstract public function publicidad() : string;

        // Método para obtener el Modelo
        public function getModelo()
        {
            // Retorna el Modelo
            return  $this->modelo;
        }
    }
    
    // Clase Hija
    class Audi extends Auto 
    {
        // Redefiniendo el método abstracto
        public function publicidad() : string 
        {
            // Retorna la publicidad
            return "Tecnología Alemana !; Soy un $this->name!";
        }
    }
    
    // Clase Hija
    class Volvo extends Auto 
    {
        // Redefiniendo la clase abstracta
        public function publicidad() : string 
        {
            // Retorna la publicidad
            return "Orgullosamente Suizo! Soy un $this->name!";
        }
    }
    
    // Clase Hija
    class Citroen extends Auto 
    {
        // Redefiniendo el método abstracto
        public function publicidad() : string 
        {
            // Retorna la publicidad
            return "La extravagancia Francesa ! Soy un $this->name!";
        }
    }
    
    // La siguiente linea no es posible
    // No se puede instanciar de clase abstractas
    // $audi = new Auto("Audi");

    // Crea un objeto de Audi
    $audi = new audi("Audi");
    echo $audi->publicidad();
    echo " Modelo:".$audi->getModelo();
    echo "\n";
    
    $volvo = new volvo("Volvo");
    echo $volvo->publicidad();
    echo " Modelo:".$audi->getModelo();
    echo "\n";
    
    $citroen = new citroen("Citroen");
    echo $citroen->publicidad();
    echo " Modelo:".$audi->getModelo();
    echo "\n";    
?>