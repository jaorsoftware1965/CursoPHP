<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 35 Herencia
    // -------------------------------------------

    // La Herencia es la capacidad de heredar las
    // caracteristicas de una clase a otra
    
    // Solo se puede heredar de una sola Clas en PHP;
    // en otros lenguajes pueden ser mas

        
    echo "Clases Herencia</br></br>";

    // Definimos una clase
    class Persona
    {
        // Properties
        public    $nombre;
        protected $apellido;
        private   $edad=33;

        function __construct ()
        {
           echo "Ejecutando Constructor de Persona</br>";
           $this->nombre  ="Juan";
           $this->apellido="Perez";
           //$this->$edad    =33;
        }

        // Metodos
        public function fnDesplegarInfoPersona() 
        {
            // coloca el nombre
            echo "Nombre   : ".$this->nombre  ."</br>";
            echo "Apellido : ".$this->apellido."</br>";
            echo "Edad     : ".$this->edad    ."</br>";
        }
        
        protected function setApellido($apellido) 
        {
            // coloca el apellido
            $this->apellidos = $apellido;
        }

        private function getApellido() 
        {
            // retorna el Apellido
            return $this->apellido;
        }
    }

    // Herencia
    class Empleado extends Persona 
    {   
        // Agregamos propiedades
        private $sueldo;
        private $area;

        function __construct ()
        {
           echo "Ejecutando Constructor de Empleado</br>";
           $this->sueldo =8500;
           $this->area   ="Contabilidad";
        }
        
        function fnDesplegarInfoEmpleado() 
        {
            // Llama a función Heredada
            $this->fnDesplegarInfoPersona();

            // Despliega los datos del Empleado
            echo "Sueldo : ".$this->sueldo  ."</br>";
            echo "Area   : ".$this->area."</br>";

            // No puedo acceder a obtener el Apellido
            //echo $this->getApellido();

        }
    }


    // Creamos un objeto
    $oPersona = new Persona();

    // Desplegamos el Nombre Completo
    echo "Información de la Persona</br>";
    $oPersona->fnDesplegarInfoPersona();
    echo "</br>";

    // No puedo usar get y set de apellido
    //$oPersona->setApellido("ojo");
    //echo $oPersona->getApellido();

    // Creo un objeto de Empleado
    $oEmpleado = new Empleado();

    echo "Información de la Persona desde Empleado</br>";
    $oEmpleado->fnDesplegarInfoPersona();
    echo "</br>";

    echo "Información del Empleado</br>";
    $oEmpleado->fnDesplegarInfoEmpleado();
    echo "</br>";



?>