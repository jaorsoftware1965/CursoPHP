<?php
    // -------------------------------------
    // Curso de Php
    // Clase 19 Sentencias break y continue
    // -------------------------------------

    // La Sentencia break finaliza el ciclo. 
    // Se puede decir que lo rompe.

    // La Sentencia continue, finaliza la iteración actual y continúa con la siguiente
    
    // Declaración de variables
    echo "Sentencia break y continue <br><br>";

    
    // Preparo la variable b
    for ($b = 0; $b < 10; $b++) 
    {
        if ($b == 9) 
        {
           break;
        }
        echo $b."<br>";
    }
    echo "El valor de \$b al final es : $b </br></br>";

    // Preparo la variable x
    for ($x = 0; $x < 10; $x++) 
    {
        if ($x == 3) 
        {
           continue;
        }
        echo $x."<br>";
    }
    echo "El valor de \$b al final es : $b </br></br>";
?>












