<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 28 Operaciones con Fecha y Hora
    // -------------------------------------------

    // La Función Date de php, nos permite poder manejar
    // la fecha y la hora.

    echo "Operaciones con Fecha y Hora</br></br>";

    
    // Declaramos variables para controlar el tiempo
    $segundosPorMinuto = 60;
    $segundosPorHora   = 60 * 60;
    $segundosPorDia    = 24 * 60 * 60;
    $segundosPorSemana = 7 * 24 * 60 * 60;


    // Obtenemos el tiempo actual
    $fechaEnSegundos = time();
    //$fechaEnSegundos = getDate()[0];

    // Imprime la fecha
    echo "a) Fecha en Segundos : ";
    print_r($fechaEnSegundos);
    echo("<br>");echo("<br>");

    echo "b) Fecha obtenida desde los segundos:";
    echo date("y.M.d h.i.s",$fechaEnSegundos);
    echo("<br>");echo("<br>");

    echo "c) Fecha mas 50 Segundos : ";
    echo date("y.M.d h.i.s",$fechaEnSegundos + 50);
    echo("<br>");echo("<br>");

    echo "d) Fecha mas 30 Minutos : ";
    echo date("y.M.d h.i.s",$fechaEnSegundos + 30 * $segundosPorMinuto);
    echo("<br>");echo("<br>");

    echo "e) Fecha mas 5 Horas : ";
    echo date("y.M.d h.i.s",$fechaEnSegundos +  5 * $segundosPorHora);
    echo("<br>");echo("<br>");

    echo "f) Fecha mas 5 Dias : ";
    echo date("y.M.d h.i.s",$fechaEnSegundos +  5 * $segundosPorDia);
    echo("<br>");echo("<br>");

    echo "g) Fecha menos 5 Dias : ";
    echo date("y.M.d h.i.s",$fechaEnSegundos -  5 *$segundosPorDia);
    echo("<br>");echo("<br>");

    echo "g2) Fecha mas 2 Semana : ";
    echo date("y.M.d h.i.s",$fechaEnSegundos +  2 * $segundosPorSemana + 1 * $segundosPorDia);
    echo("<br>");echo("<br>");


    // Sumar Dias
    $date=date_create("2013-12-01");
    date_add($date,date_interval_create_from_date_string("40 days"));

    echo "h) Fecha 2013-12-01 mas 40 Dias : ";
    echo date_format($date,"Y-m-d");
    echo("<br>");echo("<br>");

    // Restar Dias
    $date=date_create("2013-12-01");
    date_sub($date,date_interval_create_from_date_string("40 days"));

    echo "i) Fecha 2013-12-01 menos 40 Dias : ";
    echo date_format($date,"Y-m-d");
    echo("<br>");echo("<br>");

    // Crear Fecha
    $date=date_create(); // Objeto, Año, Mes, Dia
    date_date_set($date,2020,10,30);
    echo "j) Crear Fecha 2020-10-30 : ";
    echo date_format($date,"Y/m/d");
    echo("<br>");echo("<br>");

    // Print the array from gettimeofday()
    echo "k) Obtiene el Tiempo del dia : ";
    print_r(gettimeofday());
    echo("<br>");echo("<br>");

    // Print the float from gettimeofday()
    echo "l) Obtiene el Tiempo del dia con decimales : ";
    echo gettimeofday(true);
    echo("<br>");echo("<br>");
    
    echo "m) Obtiene el LocalTime : ";
    print_r(localtime());
    echo "<br><br>";

    $date1 = date_create("2013-03-15");
    $date2 = date_create("2014-03-16");
    $diff  = date_diff($date1,$date2);
    echo "n) Diferencia entre 2 fechas : ";
    print_r($diff);
    echo "<br><br>";

    echo "o) Valida Fechas : <br>";
    var_dump(checkdate(12,31,-400));
    echo "<br>";
    var_dump(checkdate(2,29,2003));
    echo "<br>";
    var_dump(checkdate(2,29,2004));
    echo "<br>";
    var_dump(checkdate(1,1,1970));
    echo "<br>";
    var_dump(checkdate(1,1,1));
    echo "<br>";
    var_dump(checkdate(1,32,1));
    echo "<br>";

    // Horario de Verano Cambia
    // 1am cambia, o sea que se adelanta
    // De la 1am pasa inmediato a las 2am
    // 1.15 am

    // 2am cambia, o sea que se atrasa
    // De la 2am pasa inmediato DE NUEVO a a la 1am
    // 1.15 am de la primera vuelta 2.am  

?>