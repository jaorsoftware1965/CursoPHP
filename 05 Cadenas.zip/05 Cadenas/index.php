<?php
// ----------------------------------
// Curso de Php
// Clase 05 Cadenas
// ----------------------------------

// En una clase previa aprendimos que las Cadenas son un tipo de dato
// el cual permite almacenar un conjunto de caracteres.

// Solamente hay dos operadores para las cadenas:
// a) "."  Ejemplo: $txt1 . $txt2
// El ejemplo anterior une las 2 cadenas

// b) ".=" Ejemplo: $txt1 .= $txt2   $txt1 = $txt1 . $txt2;
// El ejemplo anterior agrega la cadena2 a la cadena 1

// Como en todos los lenguajes de programacion, existen funciones para
// el manejo de cadenas; es decir para usarlas de alguna forma 
// especifica u obtener informacion de ellas. A continuacion veremos 
// algunas de las mas importantes.

// strlen().
// Esta funcion se utiliza para obtener la longitud de una cadena.
        
// strpos(). 
// Esta funcion se utiliza para verificar si en una cadena
// existe otra.

// strtolower(). 
// Convierte todos los caracteres de la cadena en minusculas.

// strtoupper().
// Convierte todos los caracteres de la cadena en mayusculas.

// ucfirst().
// Vonvierte el primer caracter de la cadena en mayuscula.

// ucwords().
// Convierte la primera letra de cada palabra en la cadena en mayuscula.

// trim().
// Elimina espacios en blanco al inicio y final de la cadena.

// strcmp().
// Compara 2 cadenas y retorna 0 si son iguales.

// strcasecmp().
// Compara 2 cadenas sin considerar minusculas o mayusculas.

// strrpos().
// Devuelve la posicion de la ultima ocurrencia de una cadena en otra.

// str_replace().
// Sustituye una cadena por otra 

    // Declaración de variables

    echo "Manejo de Cadenas" . "</br>";
    echo "</br>";

    // Declaramos una cadena
    $nombre = "Juan";
    $nombre .= " Jose";

    echo "nombre:".$nombre."</br>";
    echo "</br>";

    // Obtenemos su longitud
    echo "La Longitud del nombre es:".STRLEN($nombre)."</br>";
    echo "La posicion de Jose en el nombre es:".strpos($nombre,"Jose")."</br>";
    echo "</br>";

    // Le colocamos espacios al nombre para luego eliminarlos con trim
    echo "nombre con minusculas:".strtolower($nombre)."</br>";
    echo "nombre con mayusculas:".strtoupper($nombre)."</br>";
    echo "</br>";

    $nombre = "juan jose ramirez perez";
    echo "primera letra con mayuscula:".ucfirst($nombre)."</br>";
    echo "primera letra de cada palabra con mayuscula:".ucwords($nombre)."</br>";
    echo "</br>";

    $nombre = "   Juan Jose   ";
    echo "nombre con espacios A:".$nombre."</br>";
    echo "nombre con espacios B:".trim($nombre)."</br>";
    echo "nombre con espacios C:".strlen($nombre)."</br>";
    echo "nombre sin espacios D:".strlen(trim($nombre))."</br>";
    echo "</br>";

    $nombre  = "Juan Jose";
    $nombre2 = "Juan Jose";
    echo "comparando a:".strcmp($nombre,$nombre2)."</br>";
    echo "comparando b:".strcmp($nombre,"JuAN JOse")."</br>";
    echo "comparando c:".strcmp("JUAN Jose","JUAN Jose")."</br>";
    echo "</br>";

    echo "comparando e:".strcasecmp($nombre,"juan jose")."</br>";
    echo "comparando f:".strcasecmp($nombre,"juan alberto")."</br>";
    echo "comparando g:".strcasecmp("juan Alberto",$nombre)."</br>";
    echo "</br>";


    echo "buscando:".strrpos($nombre,"J")."</br>";
    echo "buscando:".strrpos($nombre,"a")."</br>";
    echo "</br>";

    echo "Reemplazando:".str_replace("Juan","Marco",$nombre)."</br>";
    echo "Reemplazando:".str_replace("Jose","Arturo",$nombre)."</br>";
    echo "nombre:".$nombre."<br>";
    
    $nuevoNombre = str_replace("Jose","Arturo",$nombre);
    echo "nuevo nombre:".$nuevoNombre."<br>";
    echo "</br>";

?>

