<?php
    // -------------------------------------
    // Curso de Php
    // Clase 24 Funciones para Arreglos
    // -------------------------------------

    // Declaración de variables
    echo "Funciones para Arreglos <br><br>";

    $personas=array("Pedro"  => 35,
                    "Benito" => 37,
                    "Jose"   => 43);

    echo "Obtenemos todas las llaves<br>";
    print_r(array_keys($personas));
    echo "</br></br>";

    echo "Llave en Mayusculas<br>";    
    print_r(array_change_key_case($personas,CASE_UPPER));
    echo "<br>";
    print_r($personas);
    echo "</br></br>";


    echo "Llave en Minusculas<br>";    
    print_r(array_change_key_case($personas,CASE_LOWER));
    echo "<br>";
    print_r($personas);
    echo "</br></br>";

    echo "Busca Jennifer en las llaves<br>";    
    echo array_key_exists("Benito",$personas);
    echo "</br></br>";    

    echo "Busca un valor y devuelve su llave<br>";
    echo array_search(35,$personas);
    echo "</br></br>";   

    // ------------------------------------------------
    // Funciones que si modifican el parametro
    // -----------------------------------------------

    echo "Agregamos valores al arreglo de colores<br>";
    $colores = array("red","green");
    print_r($colores);
    echo "</br>";
    print_r($colores = array_pad($colores,5,"yellow"));
    echo "</br></br>";

    echo "Eliminamos el ultimo valor de un arreglo<br>";
    array_pop($colores);
    print_r($colores);
    echo "</br></br>";

    echo "Insertamos al Final de un arreglo<br>";
    array_push($colores,"brown","gray");
    print_r($colores);
    echo "</br></br>";

    echo "Eliminamos el elemento en pos 2 <br>";
    unset($colores[5]);
    print_r($colores);
    echo "</br></br>";

    echo "Invierte el Arreglo<br>";
    print_r(array_reverse($colores));
    echo "</br></br>";
  
?>





























<!-- // Arreglo de Empleados
    $empleados = array(
                        array(
                            'id'       => 5698,
                            'nombre'   => 'Pedro',
                            'apellido' => 'Perez',
                        ),
                        array(
                            'id'       => 4767,
                            'nombre'   => 'Benito',
                            'apellido' => 'Bodoque',
                        ),
                        array(
                            'id'       => 3809,
                            'nombre'   => 'Jose',
                            'apellido' => 'Duarte',
                        )
                    );

    echo "Obtenemos la columna de apellidos<br>";
    $apellidos = array_column($empleados, 'apellido');
    print_r($apellidos);
    echo "</br></br>"; -->