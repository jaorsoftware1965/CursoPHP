<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 34 Modificadores Public Private Protected
    // -------------------------------------------

    // Public . 
    // Se puede acceder desde el objeto creado y 
    // clase que hereden
    
    // Protected.
    // Privado. Solo se usan en la clase y en clases
    // que hereden

    // Private .
    // Solo se pueden acceder desde la Clase
    echo "Modificadores Public Protected Private <br></br>";

    // Definimos una clase
    class Persona
    {
        // Properties
        public    $var_publica_nombre;
        protected $var_protegida_apellido;
        private   $var_privada_edad;

        function __construct()
        {
            // Desde la clase puedo acceder a las 3
            $this->var_publica_nombre     = "Juan";
            $this->var_protegida_apellido = "Perez";
            $this->var_privada_edad       = 33;
        }        
    }

    // Creamos un objeto de Persona
    $oPersona = new Persona();

    // Desplegamos el objeto
    echo "Información del Objeto:</br>";
    print_r($oPersona);
    echo "</br>";

    // Puedo acceder a la variable publica
    echo "Nombre:".$oPersona->var_publica_nombre."</br>";

    // No puedo acceder a protegidas ni privadas
    //echo "Nombre:".$oPersona->var_protegida_apellido;
    //echo "</br>";
    //echo "Nombre:".$oPersona->var_privada_edad;
    //echo "</br>";

    
    // Obtenemos cada uno de los elementos del arrego
    echo "Lista de Propiedades del Objeto:</br>";
    foreach ($oPersona as $propiedad => $valor) 
    {
        echo "Propiedad: $propiedad  Valor: $valor <br>";
    }
    echo "</br>";
?>