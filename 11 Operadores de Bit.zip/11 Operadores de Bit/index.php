<?php
    // -------------------------------------
    // Curso de Php
    // Clase 11 Operadores de Bit
    // -------------------------------------
     
    // Son aquellos que se utilizan para realizar operaciones con
    // números pero a nivel bit. A continuación los operadores.

    // Operador And &.
    // Este operador realiza la operación de And entre cada
    // cada uno de los bits que los representan
    // Ejemplo: 4 & 6 = 4   4 & 8 = 0
    // 4 = 0100             4 =  0100
    // 6 = 0110             8 =  1000
    // --------                  ----
    // 4 = 0100             0 =  0000

    // Operador Or |
    // Este operador realiza la operación de Or entre cada
    // cada uno de los bits que los representan
    // Ejemplo: 4 | 8 = 12
    // 4  = 0100
    // 8  = 1000
    // ---------
    // 12 = 1100

    // Operador Xor ^
    // Este operador realiza la operación de Xor entre cada
    // cada uno de los bits que los representan
    // Ejemplo: 4 ^ 12 = 8
    // 4  = 0100
    // 12 = 1100
    // ---------
    // 8  = 1000

    // Operador Not ~
    // Este operador realiza la operación de Complemento a 2,
    // Que invierte todos los bits del Numero
    // Ejemplo: ~4 = -5

    //  4 = 00000100
    // ~4 = 11111011 = -5
    
    // Operador de Desplazamiento a la izquierda <<
    // Desplaza los bits de un numero en la cantidad indicada
    // Ejemplo: 4 << 3 = 32
    //  4 = 00000100
    //  8 = 00001000
    // 16 = 00010000
    // 32 = 00100000
    
    // Operador de Desplazamiento a la derecha
    // Desplaza los bits de un numero en la cantidad indicada
    // Ejemplo: 14 >> 3 = 1
    // 14 = 00001110   
    //  7 = 00000111
    //  3 = 00000011
    //  1 = 00000001
    
    // Declaración de variables
    echo "Operadores de Bit <br><br>";
    
    // Preparo la variable x
    $x = 4;
    $y = 6;
    $z = 8;

    echo "a) $x & $y =";
    echo $x & $y;
    echo "<br>";
    
    echo "b) $x | $z =";
    echo $x | $z;
    echo "<br>";

    echo "c) $x ^ 12  =";
    echo $x ^ ($y * 2);
    echo "<br>";

    echo "d) ~$x =";
    echo ~$x;
    echo "<br>";

    echo "e) $x << 2 = ";
    echo $x << 2;
    echo "<br>";

    echo "f) 14 >> 2 = ";
    echo ($y + $z) >> 2;
    echo "<br>";
?>