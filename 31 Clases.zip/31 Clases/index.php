<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 31 Clases
    // -------------------------------------------

    // Una clase es como una plantilla que nos permite
    // generar objetos en base a ella.

    // Ejemplo:
    // Clase                    Objeto
    // manual fabricar auto     auto en si

    // Una clase contiene propiedades y métodos que la definen

    // Sintaxis
    // class nombreClase
    // {
    //     propiedades; (public, protected, private)
    //     metodos;     (public, protected, private)
    // }

    // Una vez que ya se tiene una clase definida, es posible
    // crear objetos en base a ella.

    // Sintaxis para crear un objeto
    // objetoCrear = new Clase()    
                
    // Definimos una clase
    class Persona
    {
        // Propiedades
        public $nombre;
        public $apellido;
        public $edad;

        // Métodos
        function setNombre($nombre) 
        {
            // coloca el nombre
            $this->nombre = strtoupper($nombre);
        }
        function getNombre() 
        {
            // retorna el nombre
            return strtolower($this->nombre);
        }
        function setApellido($apellido) 
        {
            // coloca el apellido
            $this->apellido = $apellido;
            //$this->apellido = $apellido;
        }
        function getApellido() 
        {
            // retorna el Apellido
            return $this->apellido;
        }
    }

    // Programa principal
    echo "Clases</br></br>";

    // Creamos un objeto
    $oPersona = new Persona();    

    // Desplegamos el objeto
    print_r($oPersona);
    echo "</br>";
    echo "</br>";

    var_dump($oPersona);
    echo "</br>";
    echo "</br>";

    // Colocamos datos
    $oPersona->nombre   = "juan";
    $oPersona->apellido = "perez";
    //$oPersona -> apellido = "No existia";

    print_r($oPersona);
    echo "</br>";
    echo "</br>";

    echo "Nombre   : ".$oPersona->nombre;
    echo "</br>";
    echo "Apellido : ".$oPersona->apellido;
    echo "</br>";
    echo "</br>";

    // Obtenemos cada uno de los elementos del arrego
    foreach ($oPersona as $propiedad => $valor) 
    {
        echo "Propiedad: $propiedad  Valor: $valor <br>";
    }
    echo "</br>";
    echo "</br>";

    // Usando los metodos
    $oPersona->setNombre("pedro");
    $oPersona->setApellido("Picapiedra");
    print_r($oPersona);
    echo "</br>";
    echo "</br>";

    echo "Nombre   : ".$oPersona->getNombre();
    echo "</br>";     
    echo "Apellido : ".$oPersona->getApellido();
    echo "</br>";

?>




