<?php
// ----------------------------------
// Curso de Php
// Clase 06 Operadores Aritméticos
// ----------------------------------

// Los operadores aritmeticos en la programacion son similares a los 
// conocidos en las matemáticas tradicionales. A continuación veremos 
// cada uno de ellos.

// Operador +. 
// Es el operador para realizar sumas aritmeticas. Ejemplo: $x + 5

// Operador -. 
// Es el operador para realizar restas aritmeticas. Ejemplo: $x - 3

// Operador *. 
// Es el operador para realizar multiplicaciones aritmeticas. 
// Ejemplo: $x * 3;

// Operador /. 
// Es el operador para realizar divisiones aritmeticas y obtener el 
// cociente. Ejemplo: 10 / 3

// Operador %. (Modulo o Residuo)
// Es el operador para realizar divisiones aritmeticas y obtener el 
// residuo. Ejemplo: 10 % 3

// Operador **.
// Este operador eleva el primero numero a la potencia indicada por el
// segundo operando. Ejemplo: $5**2;
        
    // Declaración de variables
    echo "Operadores Aritmeticos <br>";
    
    // Declaramos la variable x
    $x = 11;

    // Despliego x
    echo "\$x = $x"."<br>";
    echo "<br>";

    
    // Relizo la operación de suma
    $res = $x + 5;
    
    echo "\$x + 5  : ".$res."<br>";
    echo "\$x + 5  : $res<br>";
    echo "<br>";    

    echo "\$x - 5  : ".($x -  5)."<br>";
    echo "\$x * 5  : ".($x *  5)."<br>";
    echo "\$x / 5  : ".($x /  5)."<br>";
    echo var_dump($x/5)."<br>";
    echo "\$x % 5  : ".($x %  5)."<br>";
    echo "<br>";    

    echo "\$x ** 2 : ".($x ** 2)."<br>";
    echo "</br>";

?>








