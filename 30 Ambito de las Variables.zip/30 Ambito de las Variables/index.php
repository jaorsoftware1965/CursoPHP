<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 30 Ámbito de las Variables
    // -------------------------------------------

    // El ámbito de una variable es el contexto dentro del 
    // que la variable está definida. La mayor parte de las 
    // variables PHP sólo tienen un ámbito simple. Este ámbito 
    // simple también abarca los ficheros incluídos y los requeridos. 

    // Hay 2 ámbitos para las variables.
    // - El ámbito global
    // - El ámbito local

    // Una variable global está fuera de cualquier función y está disponible
    // en todo el script de php. Para poder utilizarlas dentro de una función
    // hay que indicarlo con la palabra reservada global

    // Una variable local está dentro de una función y solo está disponible
    // en el ámbito de la función

    // Las variables globales, tienen un control especial por PHP, y son almacenadas
    // en un arreglo llamado GLOBALS. Desde ese arreglo, es posible acceder a cualquier
    // variable global, usando su nombre como índice del arreglo

    // Por ejemplo: 

    // Variables global
    $a = 100;
    $b = 200;

    // Función
    function test()
    {
        // Declaro una variable local con el mismo nombre
        $a = 10;

        // Declaro global b para poder accederla desde la función
        global $b;

        /* referencia a una variable del ámbito local */
        echo $a; // Imprimira 10, porque usa la variable "a" local
        echo $b; // Imprimira 200, porque es el valor de la variable global

        // Otra forma de obtener el valor de una variable global
        // Accedemos desde el arreglo usando como índice el nombre de la variable
        echo $GLOBALS['b'];
    }

    // Ejecutamos la función
    test();
?>
