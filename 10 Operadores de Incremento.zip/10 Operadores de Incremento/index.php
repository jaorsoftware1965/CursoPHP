<?php
    // -------------------------------------
    // Curso de Php
    // Clase 10 Operadores de Incremento / decremento
    // -------------------------------------

    // Los operadores de incremento son especificos de la programación.
    // Se utilizan para incrementar o decrementar en 1 el valor de una
    // variable.

    // A continuación los operadores de Incremento de PHP

    // Operador ++
    // Incrementa en 1 la variable que lo use

    // Operador --
    // Decrementa en 1 la variable que lo use

    // Si el operador se coloca antes de la variable, esta primero
    // realiza la acción de incremento o decremento; y posteriormente
    // se utiliza la variable en la instrucción.

    // Si el operador se coloca despues de la variable, esta primero
    // se utiliza en la instrucción y posteriormente se incrementa o
    // decrementa en la variable. 
    // Si el operador esta despues, no le hace NADA. Solo hasta que
    // termina la instruccion

    // Declaración de variables
    echo "Operadores de Incremento o Decremento <br>";
    
    // Preparo la variable x
    // $x = 10;    
    // $x++;
    // echo "a)El valor de x:".$x."<br>"; // 11

    // $x = 10;    
    // ++$x;
    // echo "b)El valor de x:".$x."<br>"; // 11


    // $x = 10;    
    // $x--;
    // echo "c)El valor de x:".$x."<br>"; // 9

    // $x = 10;    
    // --$x;
    // echo "d)El valor de x:".$x."<br>"; // 9
    // echo "<br>";


    // $x = 10;
    // echo "e)El valor de x:".$x++."<br>"; // 10
    // // Suceden 2 cosas
    // // 1o la Impresion
    // // 2d el incremento
    // echo $x."<br>";

    // $x = 10;
    // echo "f)El valor de x:".++$x."<br>"; // 11
    // // 1o el incremento
    // // 2o es la impresion
    // echo $x."<br>";


    // $x = 10;
    // echo "g)El valor de x:".$x--."<br>"; // 10
    // // Suceden 2 cosas
    // // 1o la Impresion
    // // 2d el decremento
    // echo $x."<br>";// 9

    // $x = 10;
    // echo "h)El valor de x:".--$x."<br>"; // 9
    // // 1o el decremento
    // // 2o es la impresion
    // echo $x."<br>";// 9

    
    $x = 5;
    // Cuanto vale x en este momento ? 5

    $x++; // Cuanto vale x en este momento ? 5
    // Cuanto vale x en este momento ? 6

    $x = 5;
    // Cuanto vale x en este momento ? 5

    --$x; // Cuanto vale x en este momento ? 4
    // Cuanto vale x en este momento ? 4
     
    $x = 5;
    // Cuanto vale x en este momento ? 5

    echo ++$x;// Cuanto vale x en este momento ? 6
    // Cuanto vale x en este momento ? 6

    $x = 3;
    echo "El valor de x:".++$x."<br>";   // 4
    
    $x = 7;
    echo "El valor de x:".$x++."<br>";  // 7

    $x = 13;
    echo "El valor de x:".--$x."<br>";  // 12
    
    $x = 27;
    echo "El valor de x:".$x--."<br>";  // 27
    
    $x = 10;
    $y = 7;

    

    // //echo "El valor de 5 * \$x++:";
    // echo 5 * $x++."<br>";
    // echo "El valor de \$x despues de la instruccion:".$x."<br>";
    // //echo "El valor de \$x :".$x."<br>";// 12
    // echo "<br>";

    // // Preparo la variable x
    // $x = 10;
    // //echo "El valor de 5 * ++\$x:";
    // echo 5 * ++$x."<br>";
    // echo "El valor de \$x despues de la instruccion:".$x."<br>";
    // //echo "El valor de \$x :".$x."<br>";// 10
    // echo "<br>";


    // // Preparo la variable x
    // $x = 10;    
    // //echo "El valor de 5 * \$x--:";
    // echo 5 * $x--."<br>";
    // echo "El valor de \$x despues de la instruccion:".$x."<br>";
    // //echo "El valor de \$x :".$x."<br>";// 10
    // echo "<br>";

    // // Preparo la variable x
    // $x = 10;
    // //echo "El valor de 5 * --$\x:";
    // echo 5 * --$x."<br>";
    // echo "El valor de \$x despues de la instruccion:".$x."<br>";
    // //echo "El valor de \$x :".$x."<br>";// 
    // echo "<br>";

?>


