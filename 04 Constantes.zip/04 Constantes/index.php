<?php
// ---------------------------------
// Curso de Php</h1>
// Clase 04 Constantes
// ---------------------------------

// Las constantes son espacios de memoria que almacenan informacion 
// y que no pueden cambiar; por eso se llaman constantes.

// Las Constantes en PHP inician con una Letra o el caracter de 
// subrayado; seguido de letras numeros o mas caracteres de 
// subrayados

// Solo se pueden definir como constantes valores escalares:boolean,
// integer, float y string.
    
// Es una buena costumbre de programación que las constantes se 
// escriban siempre en mayusculas.

// El ámbito o alcance operativo de una Constante es global, 
// es decir que se puede hacer uso de ella en cualquier parte del 
// programa.

// Para definir una constante se hace de la siguiente forma:

// define("nombreConstante","valor_constante"). Ejemplo:<br>
// define("SISTEMA_NOMBRE","Sistema de Ventas")</p>

    // Mensaje de la Clase
    echo "Declarando Constantes </br>";    

    // Declaración de Constantes
    DEFINE("STR_SISTEMA"  , "Sublime Word");
    define("FLT_VERSION"  , 3.15);
    define("INT_TERMINAL" , 4);    
    echo "</br>";
    
    // Desplegamos los valores de las constantes
    echo "Desplegando el valor de las Constantes </br>";
    echo "STR_SISTEMA  :".STR_SISTEMA."<br>";
    echo "FLT_VERSION  :".FLT_VERSION."<br>";
    echo "INT_TERMINAL :".INT_TERMINAL."<br>";
    echo "</br>";
    
    // Desplegamos información de las Constantes
    echo "Desplegando el tipo de dato de las Constantes </br>";
    echo var_dump(STR_SISTEMA) ."<br>";
    echo var_dump(FLT_VERSION) ."<br>";
    echo var_dump(INT_TERMINAL)."<br>";
    echo "</br>";

?>