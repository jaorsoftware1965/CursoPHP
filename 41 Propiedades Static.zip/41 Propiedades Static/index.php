<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 41 Propiedades Estáticas
    // -------------------------------------------

    // Así como hay métodos estáticos, tambien existen
    // propiedades estáticas las cuales pueden ser accedidas
    // directamente desde la clase, sin una instancia u objeto
    // de la misma

    // Al igual que con los métodos, se crean con la palabra "static"
    // Ejemplo:

    // Mensaje de la Clase    
    echo "Clase 41 Métodos Estáticos\n\n";

    // Definimos una clase
    class testClase 
    {
        // Definimos una propiedad estática de la clase
        public static $propiedadStatic = "Contenido de Variable estática de la Clase";
    }

    // Accedemos a la propiedad estática
    echo testClase::$propiedadStatic;
    echo "\n";

    // Lo mismo que con los Métodos, una clase puede tener propiedades estáticas y
    // ser accedidas desde la clase

    // Clase Padre
    class figuraGeometrica
    {
        // Definimos propiedad estática y propiedad no estática
        public static $pi = 3.14159;

        // Función statica que accede la propiedad
        public function getPI() 
        {
            // Retorna el valor de pi
            return self::$pi;
        }
    }
  
    // Crea un objeto
    $figura = new figuraGeometrica();

    // Despliega el valor de Pi
    echo "El valor de PI:";
    echo $figura->getPI(); 
    echo "\n";

    // Es posible acceder a una propiedad static desde una clase hija, utilizando
    // la palabra reservada parent.

    // Declaramos circulo como hija de figuraGeometrica
    class circulo extends figuraGeometrica 
    {
        // Retornamos el valor de pi
        public function getPICirculo() 
        {
            // Retornamos el valor de la propiedad en clase padre
            return parent::$pi;
        }
    }

    // Creamos un objeto de circulo
    $xCirculo = new circulo();

    // Desplegamos el valor de Pi
    echo "El Valor de PI desde el Circulo:";
    echo $xCirculo->getPICirculo(); 
    echo "\n";

?>