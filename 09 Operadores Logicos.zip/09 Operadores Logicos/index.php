<?php
    // --------------------------
    // Curso de Php
    // Clase 09 Operadores Lógicos
    // --------------------------

    // Los operadores lógicos son aquellos que se utilizan para realizar
    // operaciones con operandos lógicos y el valor que devuelven es un
    // valor lógico: true o false.

    // A continuación los operadores lógicos de PHP

    // Operador and &&
    // Devuelve true solo cuando ambos son true

    // Tablas de Verdad de and
    // Operando1          Operando2      Operacion and
    //  True  (1)   and      True  (1)      True
    //  True  (1)   and      False (0)      False
    //  False (0)   and      True  (1)      False
    //  False (0)   and      False (0)      False
    
    // El operador and solo dara true cuando cuando los 2 sean true
    // EL operador and dara falsa cuando alguno de los 2 sea falso
    // o los 2

    // Operador or  ||
    // Devuelve false solo cuando ambos son false
    // Operando1          Operando2  Operancion Or
    //  True  (1)   or       True  (1)      True
    //  True  (1)   or       False (0)      True
    //  False (0)   or       True  (1)      True
    //  False (0)   or       False (0)      False

    // El operador or dara true cuando cuando alguno de los 2 
    // o los 2 sean true
    // EL operador or dara false cuando los 2 sean falso


    // Operador xor
    // Devuelve true solo cuando ambos son distintos
    // Operando1          Operando2  Operancion xor
    //  True  (1)  xor    True  (1)      False
    //  True  (1)  xor    False (0)      True
    //  False (0)  xor    True  (1)      True
    //  False (0)  xor    False (0)      False

    // Operador not !
    // Invierte el valor
    // Operando1   Operacion !
    //  True  (1)      False (0)
    //  False (0)      True  (1)


    // Declaración de variables
    echo "Operadores Logicos <br> <br>";
    $x = 10;
    $y = 5;
    $z = 7;

    echo "El valor de \$x :".$x."</br>";
    echo "El valor de \$y :".$y."</br>";
    echo "El valor de \$z :".$z."</br></br>";

    echo "x) True && True > :";
    echo var_dump(True && True)."<br>";
    echo "<br>";

    echo "a) $x > $y && $x > $z:";
    echo var_dump($x > $y and $x > $z)."<br>";
    echo "<br>";

    echo "b) $x > $y && $x < $z:";
    echo var_dump($x > $y && $x < $z)."<br>";
    echo "<br>";

    echo "c) $x > $y || $x < $z:";
    echo var_dump($x > $y or $x < $z)."<br>";
    echo "<br>";

    echo "d) $x < $y || $x < $z:";
    echo var_dump($x < $y || $x < $z)."<br>";
    echo "<br>";

    echo "e) $x > $y xor $x < $z:";
    echo var_dump($x > $y xor $x < $z)."<br>";
    echo "<br>";

    echo "f) $x > $y xor $x > $z:";
    echo var_dump($x > $y xor $x > $z)."<br>";
    echo "<br>";

    echo "g) !($x > $y):";
    echo var_dump(!($x > $y))."<br>";
    echo "<br>";

    echo "h) !($x < $y):";
    echo var_dump(!($x < $y))."<br>";
    echo "<br>";
?>

