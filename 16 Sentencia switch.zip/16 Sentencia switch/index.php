<?php
    // -------------------------------------
    // Curso de Php
    // Clase 16 Sentencia switch
    // -------------------------------------
    
    // Se ejecuta el código en base a una expresión
    // la cual puede tomar varios posibles valores

    // switch (n) 
    // {
    //   case label1:
    //     code to be executed n=label1;
    //     break;
    //   case label2:
    //     code to be executed n=label2;
    //     break;
    //   case label3:
    //     code to be executed n=label3;
    //     break;
    //     ...
    //   default:
    //     code to be executed if n is different from all
    //     breaK;
    // }

    // Declaración de variables
    echo "Sentencia switch  <br>";

    // Dia Semana
    $diaSemana = "Lunes";

    switch ($diaSemana) 
    {
      case "Lunes":
        echo "El dia 1";
        break;
      
      case "Martes":
        echo "El dia 2";
        break;
      
      case "Miercoles":
        echo "El dia 3";
        break;

      case "Jueves":
        echo "El dia 4";
        break;  

      case "Viernes":
        echo "El dia 5";
        break;

      case "Sabado":
        echo "El dia 6";
        break;  

      case "Domingo":
        echo "El dia 7";
        break;  

      default:
        echo "El nombre del dia no es correcto";
        break;      
    }
    
    // Cambia de Linea
    echo "<br>";

    // Dia Mes
    $numeroMes = 9;

    switch ($numeroMes) 
    {
      case 1:
        echo "El Mes Enero";
        break;
      
      case 2:
        echo "El Mes Febrero";
        break;
      
      case 3:
        echo "El Mes Marzo";
        break;

      case 4:
        echo "El Mes Abril";
        break;  

      case 5:
        echo "El Mes Mayo";
        break;

      case 6:
        echo "El Mes Junio";
        break;  

      case 7:
        echo "El Mes Julio";
        break;  

      case 8:
        echo "El Mes Agosto";
        break;    

      case 9:
        echo "El Mes Septiembre";
        break;  
      
      case 10:
        echo "El Mes Octubre";
        break;  
      
      case 11:
        echo "El Mes Noviembre";
        break;  
      
      case 12:
        echo "El Mes Diciembre";
        break;  

      default:
        echo "El numero del Mes no es correcto";
        break;
    }
?>