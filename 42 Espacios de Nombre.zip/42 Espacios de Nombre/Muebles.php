<?php
    // Declara el Espacio de Nombres
    namespace Muebles;

    // Declara la clase
    class Table 
    {
        // Declara la función para obtener la infor
        public function getInfo() 
        {
            // Despliega la info
            echo "Table como un Muebles";
        }
    }
?>    
