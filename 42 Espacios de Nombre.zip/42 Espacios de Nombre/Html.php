<?php

    // Declaramos un espacio de nombres
    namespace Html;

    // Declaramos la clase Table
    class Table 
    {
        // Función para obtener la información
        public function getInfo() 
        {
            // Desplegamos la tabla
            echo "Table de HTML";
        }
    }
?>
    
