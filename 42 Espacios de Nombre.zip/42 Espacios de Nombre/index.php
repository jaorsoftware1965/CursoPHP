<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 42 Espacio de Nombres
    // -------------------------------------------

    // Mensaje de la Clase    
    //echo "Clase 42 Métodos Estáticos\n\n";

    // Los espacios de nombres son calificadores que 
    // resuelven dos problemas diferentes:

    // - Permiten una mejor organización al agrupar clases 
    //   que trabajan juntas para realizar una tarea.
    // - Permiten utilizar el mismo nombre para más de una clase

    // Por ejemplo, puede tener un conjunto de clases que describen 
    // una tabla HTML, como table, row y cell, y al mismo tiempo 
    // tener otro conjunto de clases para describir muebles, table, 
    // chair y bed. 
    
    // Los espacios de nombres se pueden usar para organizar las clases
    // en dos grupos diferentes y, al mismo tiempo, evitar que se mezclen 
    // las clases Table y Table.

    // Los nombres de espacio son declarados al inicio de un script de php
    // utilizando la palabra reservada "namespace".

    // Incluimos los archivos con las clases con espacios de nombre
    include "Html.php";
    include "Muebles.php";

    // Crea el objeto
    $tableHtml = new Html\Table();

    // Despliega la info
    $tableHtml->getInfo();
    echo "\n";

    // Crea el objeto
    $tableMuebles = new Muebles\Table();

    // Despliega la info
    $tableMuebles->getInfo();
    echo "\n";



?>
    
