<?php
// -------------------------------------
// Curso de Php
// Clase 07 Operadores de Asignación
// -------------------------------------

// Los operadores de asignacion son los que nos permiten asignar 
// valores a las variables u otros objetos.

// El operador de asignacion tradicional y que ya hemos estado 
// utilizando es el '='.

// En programacion existen otros operadores de asignacion que sirven 
// para asignar valores, pero ademas realizan una operacion adicional.
// Los operadores son los siguientes:

// Operador +=.
// Este operador realiza una suma previa y posteriormente realiza la
// asignacion. Ejemplo: x += 5.
// La anterior expresion es similar a: x = x + 5.


// Operador -=.
// Este operador realiza una resta previa y posteriormente realiza la
// asignacion. Ejemplo: x-=5.
// La anterior expresion es similar a: x = x - 5.

// Operador *=. 
// Este operador realiza una multiplicacion previa y posteriormente
// realiza la asignacion. Ejemplo: x *= 5.
// La anterior expresion es similar a: x = x * 5.

// Operador /=.
// Este operador realiza una division previa para obtener el cociente y
// posteriormente realiza la asignacion. Ejemplo: x/=5.
// La anterior expresion es similar a: x = x/5.

// Operador %=. 
// Este operador realiza una division previa para obtener el residuo y
// posteriormente realiza la asignacion. Ejemplo: x%=5.
// La anterior expresion es similar a: x = x % 5.

// Operador **=. 
// Este operador realiza una division previa para obtener el residuo y
// posteriormente realiza la asignacion. Ejemplo: x**=5.
// La anterior expresion es similar a: x = x**5.

// Operador .=.
// Este operador realiza una concatenacion previa y posteriormente 
// realiza la asignacion. Ejemplo: $x .= "algo".
// La anterior expresion es similar a: $x = x$ + "algo".


    // Operadores de Asignacion
    echo "Operadores de Asignacion <br>";
    echo "<br>";
    
    // Declaro variable $x
    $x = 5;

    // Despliego el valor de $x
    echo "El valor de x: ".$x;
    echo "<br>";
    echo "<br>";

    $x += 7; // x = x + 7;
    echo "El resultado de x += 7: ".$x;
    echo "<br>";
    echo "<br>";

    $x -= 5;
    echo "El resultado de x -= 5: ".$x;
    echo "<br>";
    echo "<br>";

    $x *= 5;
    echo "El resultado de x *= 5: ".$x;
    echo "<br>";
    echo "<br>";

    $x /= 5;
    echo "El resultado de x /= 5: ".$x;
    echo "<br>";
    echo "<br>";

    $x %= 5;
    echo "El resultado de x %= 5: ".$x;
    echo "<br>";
    echo "<br>";

    $x **= 5;
    echo "El resultado de x **= 5: ".$x;
    echo "<br>";
    echo "<br>";

    // Declaro variable de cadena
    $x  = "Hola Mundo";

    // Despliego la variable de cadena
    echo "Este es el valor de x:";
    echo $x;
    echo "</br>";

    // Utilizo el operador de adignacion cadena
    $x .= " Saludos";
    echo "El resultado de x .= 'Saludos':".$x;        

?>