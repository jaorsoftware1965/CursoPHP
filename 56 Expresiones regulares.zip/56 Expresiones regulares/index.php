<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 56 Expresiones Regulares
    // -----------------------------------------------

    // ¿Qué es una expresión regular?
    // Una expresión regular es una secuencia de caracteres que forma un patrón de 
    // búsqueda. Cuando busca datos en un texto, puede usar este patrón de búsqueda 
    // para describir lo que está buscando.
    // Una expresión regular puede ser un solo carácter o un patrón más complicado.
    // Las expresiones regulares se pueden utilizar para realizar todo tipo de 
    // operaciones de búsqueda y reemplazo de texto.

    // En PHP, las expresiones regulares son cadenas compuestas por delimitadores, 
    // un patrón y modificadores opcionales.
    // Ejemplo:
    // $exp = "/jaorsoftware/i";

    // En el ejemplo anterior, / es el delimitador, jaorsoftware es el patrón que se 
    // busca; i es un modificador que hace que la búsqueda no distinga entre mayúsculas 
    // y minúsculas.

    // El delimitador puede ser cualquier carácter que no sea una letra, un número, 
    // una barra invertida o un espacio. El delimitador más común es la barra 
    // inclinada (/), pero cuando su patrón contiene barras inclinadas, es conveniente 
    // elegir otros delimitadores como # o ~.

    // Funciones de expresiones regulares
    // PHP proporciona una variedad de funciones que le permiten usar expresiones 
    // regulares. Las funciones preg_match(), preg_match_all() y preg_replace() son 
    // algunas de las más utilizadas:

    // preg_match()     Devuelve 1 si el patrón se encontró en la cadena y 0 si no
    // preg_match_all() Devuelve el número de veces que se encontró el patrón en la 
    //                  cadena, que también puede ser 0
    // preg_replace()   Devuelve una nueva cadena donde los patrones coincidentes 
    //                  han sido reemplazados por otra cadena
    
    // Ejemplos:

    // Declara la cadena y el patron a buscar
    $str     = "Visita JaorSoftware";
    $pattern = "/jaorsoftware/i";

    // Usa la función para buscar el patrón en la cadena
    echo "a)".preg_match($pattern, $str); // La Salida es 1
    echo "\n";

    // Declara la cadena y el patron a buscar
    $str = "En un lugar de youtube del cual no puedo olvidarme.";
    $pattern = "/de/i";
    echo "b)".preg_match_all($pattern, $str); // La Salida es 2
    echo "\n";

    // Declara la cadena y el patron a buscar
    $str = "Visita Microsoft!";
    $pattern = "/microsoft/i";
    echo "c)".preg_replace($pattern, "JaorSoftware", $str); // Salida "Visita JaorSoftware!"

?>