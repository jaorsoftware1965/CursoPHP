<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 44 jason
    // -------------------------------------------

    // ¿Qué es JSON?   
    // JSON significa Notación de objetos de JavaScript y es una sintaxis 
    // para almacenar e intercambiar datos.
    // Dado que el formato JSON es un formato basado en texto, 
    // puede enviarse fácilmente hacia y desde un servidor y utilizarse 
    // como formato de datos por cualquier lenguaje de programación.

    // Un objeto JSON es un conjunto de pares de datos, separados por ","
    // los cuales se encuentran delimitados por "{}".
    // Al primer dato se le conoce como llave o índice, y al siguiente dato
    // se le conoce como valor. Este par de datos se encuentra separado
    // por ":". Ejemplo    
    // '{"Peter":35,"Ben":37,"Joe":43}';

    // Las llaves siempre se encuentran delimitadas por comillas dobles.
    
    // PHP tiene algunas funciones integradas para manejar JSON.
    // Primero, veremos las siguientes dos funciones:

    // json_encode() Para codificar datos en json
    // json_decode() Para decodificar datos json

    // Para acceder a los datos de un objeto JSON de utiliza el operador "->"
    // Se coloca primero el objeto JSON seguido de este simbolo, y luego la llave
    // del Dato. Ejemplo:
    // $oJSON->Peter;


    // definimos un arreglo
    $Alumnos = array("Pedro"=>35, "Benito"=>37, "Jose"=>43);

    // Desplegamos el arreglo en formato json
    echo "El Arreglo:\n";
    print_r($Alumnos);
    echo "En formato json:\n";
    echo json_encode($Alumnos);
    echo "\n\n";

    // Definimos una variable en json    
    $oJSON = '{"Peter":35,"Benito":37,"Jose":"43"}';
    echo "El objeto json:".$oJSON."\n";
    echo "Convertido a un arreglo:\n";
    print_r(json_decode($oJSON));
    echo "\n\n";    

    // Para poder recorrer un objeto json, primero se convierte a arreglo
    echo "Los Elementos del objeto json:\n";

    // Se puede recorrer con un ciclo foreach
    foreach(json_decode($oJSON) as $key => $value) 
    {
        echo $key . " => " . $value . "\n";
    }    

    
?>