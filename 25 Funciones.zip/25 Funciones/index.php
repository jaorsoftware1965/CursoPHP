<?php
    // -------------------------------------
    // Curso de Php
    // Clase 25 Funciones 
    // -------------------------------------

    // Una función es un bloque de código al cual se
    // le asocia un nombre, y con este nombre, la 
    // función se llama para que se ejecute.

    // function functionName([Parametros])[:tipo] 
    // {
    //     code to be executed;
    // }

    // --------------------------------------------------
    // Funciones
    // --------------------------------------------------

    // Declaramos una función
    function fnDesplegarTituloClase()
    {
        // Desplegamos el Título de la Clase
        echo "Funciones de Usuario<br><br>";
    }

    // Función con parametros 
    function fnSaludo(string $nombre)
    {
        // Saluda
        echo "Hola ".$nombre."<br>";
    }

    // Funciones que retornan un valor (opcional el tipo)
    function fnIntSumaDosNumeros(int $x, int $y):int
    {
        // retorna
        echo $x + $y;
        echo "</br>";
        return $x + $y;
    }

    // --------------------------------------
    // Codigo Principal
    // --------------------------------------

    // Ejecuto la función
    fnDesplegarTituloClase();

    // Ejecuto el Saludo
    fnSaludo("Norma");
    fnSaludo("Kioan");
    fnSaludo("Andrea");
    echo "</br>";


    // Ejecuto la función
    echo "La suma de 80 y 17 es:";
    $res = fnIntSumaDosNumeros(80,17);
    echo $res;
    echo "<br>";    
    
?>