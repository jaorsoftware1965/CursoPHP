<?php
    // -------------------------------------
    // Curso de Php
    // Clase 21 Ciclo foreach
    // -------------------------------------

    // El Ciclo foreach se utiliza para recorrer
    // un arreglo.
    // Únicamente funciona con arreglos.
    
    // foreach ($array as $value) {
    //   code to be executed;
    // }

    // foreach ($array as $llave => $value) {
    //   code to be executed;
    // }
    
    // Declaración de variables
    echo "Ciclo for each </br></br>";

    // Definimos un arreglo de colores
    $colores = array
    (
        "rojo"  , 
        "verde" , 
        "azul"  , 
        "amarillo"
    );

    //$colores[123]="Purpura";
    //var_dump($colores);
    //echo "<br>";echo "<br>";
    print_r($colores);
    echo "<br>";echo "<br>";


    // Obtenemos cada uno de los elementos del arrego
    foreach ($colores as $color) 
    {
        echo "El Color es: ".$color." <br>";
    }

    // Dejamos una linea en blanco
    echo "<br>";
 
    // Declaramos un arreglo asociativo   
    $closet = array
    ( 
        "45" => "Vestido Negro",
        "Blusa Naranja", 
        "Pantalon Mezclilla"
    );

    // Ciclo para cada una de las edades
    foreach ($closet as $llave =>  $valor) 
    {
        echo "$llave = $valor<br>";
    }   
    print_r($closet);
    echo "<br>";echo "<br>";
    
?>
