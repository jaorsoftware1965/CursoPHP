<?php
// ----------------------------------
// Curso de Php
// Clase 01 Introducción
// ----------------------------------
// 1.- Que es PHP?
// Es un Lenguaje Interpretado que se ejecuta en un Servidor Web
// El Servidor Web ejecuta el Archivo PHP y devuelve un Documento HTML

// html-->chrome
// php ---servidor web --> chrome

// 2.- Que contiene un Archivo PHP?
// Contiene instrucciones en Php, Html y Lenguaje Script

// 3.- El Código Php siempre inicia con '<?php' y finaliza con '? >'

// 4.- La Instrucción echo se utiliza para mandar información al
// Documento que retornará el Servidor Web

// Esto es 
// un comentario y Sublime lo va a comentar
// Norma

echo "Curso de Php"."<br><hr>"."Hola Andrea<br>";
echo "Clase 01 Introduccion<br>";
echo "<ul>";
echo "  <li>Opcion 1</li>";
echo "  <li>Opcion 2</li>";
echo "</ul>";
?>



