<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 27 Fecha y Hora
    // -------------------------------------------

    // La Función Date de php, nos permite poder manejar
    // la fecha y la hora.

    // Sintaxis
    // date(format,[timestamp])  
    // 
    // format.     Indica el Formato
    // [timestamp] Es un valor numérico en segundos
    //             que representa la fecha y hora. 
    //             Default es el de la
    //             computadora. 01-Ene-1970 00:00:00

    // Formatos disponibles:
    // d - dia del Mes; del 01-31
    // D - nombre corto del día de la semana; de Mon-Sun
    // w - dia de la Semana; 1-7
    // l - nombre del dia de la semana
    // z - dia del año; 1-365
    // W - semana del año; 1-52
    // m - numero del Mes; 1-12
    // M - nombre corto del Mes; Jan-Dec
    // t - numero de dias que tiene el mes; 1-31
    // y - año en 2 digitos
    // Y - Año en 4 dígitos
    // h - hora en formato de 12; 1-12
    // H - Hora en formato de 24; 1-24
    // i - minutos; 1-59
    // s - segundos; 1-59

    // Creamos una fecha con
    // mktime(hour, minute, second, month, day, year)
    
    echo "La Fecha y la Hora</br></br>";

    echo "Fecha en 12 hrs: ".date("l d-m-y h.i.sa")."<br>";
    echo "Fecha en 24 hrs: ".date("l Y-m-d H.i.sa")."<br>";
    echo "<br>";
    echo "Nombre del dia es :" . date("l"). "<br>";
    echo "Dia de la Semana :" . date("w"). "<br>";
    echo "Dia del año :" . date("z"). "<br>";
    echo "La Semana en que estamos es:".date("W")."<br>";
    echo "<br>";

    // Creamos una fecha mayor o igual 01-Ene-1970 00:00:00
    $fecha = mktime(11, 14, 54, 9, 14, 2014);

    echo "print_r del objeto creado con mktime-->";
    print_r($fecha);
    echo "<br>";
    echo "var_dump del objeto creado con mktime-->";
    var_dump($fecha);
    echo "<br>";
    echo "var_dump de date-->";
    var_dump(date("Y-m-d h:i:sa", $fecha));
    echo "<br>";
    echo "<br>";

    echo "Fecha Creada 1 : " .date("Y-m-d h:i:sa", $fecha);
    echo "</br>";
    echo "Dia del año:".date("z", $fecha) . "<br>";
    echo "<br>";echo "<br>";

    $fecha = strtotime("10:30:14pm April 15 2014");
    echo "var_dump de fecha------------->";
    var_dump($fecha);
    echo "<br>";

    echo "Fecha Creada 2 : " .date("Y-M-d h:i:sa", $fecha);
    echo "<br>";echo "<br>";

    $fecha = strtotime("tomorrow");
    echo "Fecha Creada 3 : " .date("Y-M-d h:i:sa", $fecha);
    echo "<br>";echo "<br>";

    $fecha=strtotime("next Saturday");
    echo "Fecha Creada 4 : " .date("Y-M-d h:i:sa", $fecha);
    echo "<br>";echo "<br>";

    $fecha=strtotime("+3 Months");
    echo "Fecha Creada 5 : " .date("Y-M-d h:i:sa", $fecha);
    echo "<br>";echo "<br>";

    $fechaInicial = strtotime("next Sunday");
    $fechaFinal   = strtotime("+6 weeks", $fechaInicial);
    
    // Ciclo para imprimir
    while ($fechaInicial < $fechaFinal) 
    {
        echo date("-->>>>>>>M d", $fechaInicial) . "<br>";
        $fechaInicial = strtotime("+1 day", $fechaInicial);
    }
    echo "<br>";
    
    $d1 = strtotime("September 16"); // En Seg 16/sep/21
    $d2 = ceil(($d1-time())/60/60/24);
    echo "Faltan " .$d2." dias para el 16 de Septiembre.";
    echo "<br>";
    echo "<br>";

    echo "Fecha Estructurada : ";
    $fechaEstructurada = getDate();
    print_r($fechaEstructurada);
    echo "</br>";
    echo "</br>";

    echo "Segundos Transcurridos:".$fechaEstructurada[0];
    echo "</br>";
    echo "Seconds:".$fechaEstructurada["seconds"];
    echo "</br>";
    echo "WeekDay:".$fechaEstructurada["weekday"];
    echo "</br>";
    echo "Hours:".$fechaEstructurada["hours"];
    echo "</br>";
    echo "</br>";

?> 
Ejercicio
1.- Desplegar la fecha y hora de hoy
2.- Desplegar el nombre del dia
3.- Desplegar el numero del dia