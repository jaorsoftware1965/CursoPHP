<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 39 Interfaces
    // -------------------------------------------

    // Las interfaces son clases en las cuales todos los
    // métodos deben ser abstractos y no se permite la
    // declaración de propiedades.

    // Cuando una o más clases utilizan la misma interfaz, 
    // se denomina "polimorfismo".

    // Las interfaces se declaran con la palabra clave de interfaz.
    // Ejemplo

    // interface InterfaceName 
    // {
    //     public function someMethod1();
    //     public function someMethod2($name, $color);
    //     public function someMethod3() : string;
    // }

    // Obligatoriamente, en una interfaz todos los métodos son abstractos.
    // pero no se espefican con la palabra reservada.
    // Para heredar de una Interface se utiliza implements en lugar e
    // extend

    
    // Mensaje de la Clase    
    echo "Clase 39 Interfaces\n\n";

    // Clase Padre
    interface Auto 
    {
        // Método 
        public function getNombre() : string;
        public function getOrigen() : string;
    }
    
    // Clase Hija
    class Volkswagen implements Auto 
    {
        // Redefiniendo el método
        public function getNombre() : string 
        {
            // Retorna la publicidad
            return "Sedan";
        }
        
        // Redefiniendo el método
        public function getOrigen() : string 
        {
            // Retorna la publicidad
            return "Alemania";
        }
    }
    
    // Clase Hija
    class Ford implements Auto 
    {
        // Redefiniendo el método
        public function getNombre() : string 
        {
            // Retorna la publicidad
            return "Mustang";
        }
        
        // Redefiniendo el método
        public function getOrigen() : string 
        {
            // Retorna la publicidad
            return "USA";
        }
    }
    
    // Clase Hija
    class Nissan implements Auto 
    {
        // Redefiniendo el método
        public function getNombre() : string 
        {
            // Retorna la publicidad
            return "Tsuru";
        }

        // Redefiniendo el método
        public function getOrigen() : string 
        {
            // Retorna la publicidad
            return "Japones";
        }
    }
    
    // La siguiente linea no es posible
    // No se puede instanciar de una interfaz; no tiene constructor
    // $audi = new Auto("");

    // Crea un objeto de Audi
    $vocho = new Volkswagen();
    echo "Auto:";
    echo $vocho->getNombre();
    echo " Origen:";
    echo $vocho->getOrigen();
    echo "\n";
    echo "\n";

    // Creo un auto de la Ford
    $miFord = new Ford();
    echo "Auto:";
    echo $miFord->getNombre();
    echo " Origen:";
    echo $miFord->getOrigen();
    echo "\n";
    echo "\n";

    // Creo un auto de la Nissan
    $miNissan = new Nissan();
    echo "Auto:";
    echo $miNissan->getNombre();
    echo " Origen:";
    echo $miNissan->getOrigen();
    echo "\n";
    echo "\n";


    
    
?>