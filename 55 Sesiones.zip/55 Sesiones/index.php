<?php
    // -----------------------------------------------
    // Curso de Php
    // Clase 55 Sesiones
    // -----------------------------------------------

    // ¿Qué es una sesión?

    // Una Sesión es una forma de almacenar información en variables
    // controladas por php, las cuales se mantienen durante la navegación
    // de diversas páginas.
    
    // Las variables de sesión contienen información sobre un solo usuario 
    // y están disponibles para todas las páginas en una aplicación.

    // Una sesion se inicia con la función session_start().
    // Las Variables de Sesion se depositan en un arreglo global que controla
    // PHP y que es nombrado $_SESSION.

    // Para acceder a cada variable registrada en el arreglo de Sesión, se
    // coloca el nombre del arreglo de sesion; $_SESSION y entre corchetes, el
    // nombre de la variable de sesión.

    // Para modificar el valor de una variable de Sesión se hace de la misma
    // forma; accediendo a la variable a través del arreglo y con el nombre de
    // la variable como indice; y colocando el valor que se desea.

    // Start the session
    session_start();

    // Mensaje
    echo "Sesion iniciada ...\n";

    // Set session variables
    $_SESSION["color"] = "verde";
    $_SESSION["fruta"] = "gato";

    // Mensaje
    echo "Variables de Sesion registradas ...\n\n";
    
    echo "Arreglo de Sesion:\n";
    print_r($_SESSION);
    echo "\n";
    echo "\n";

    echo "Desplegando las variables de Sesión una por una:\n";
    echo "Color: " . $_SESSION["color"] . "\n";
    echo "Fruta: " . $_SESSION["fruta"] . "\n";
    echo "\n";

    echo "Modificando las variables de Sesión una por una:\n";
    $_SESSION["color"] = "rojo";
    $_SESSION["fruta"] = "manzana";
    echo "\n";

    echo "Desplegando las variables de Sesión una por una:\n";
    echo "Color: " . $_SESSION["color"] . "\n";
    echo "Fruta: " . $_SESSION["fruta"] . "\n";
    echo "\n";

    // Eliminando
    echo "Eliminando Variables de Sesión ...\n";
    session_unset();

    echo "Desplegando las variables de Sesión que ya no existen:\n";
    // Lo siguiente marcará un Notice de PHP
    echo "Color: " . $_SESSION["color"] . "\n";
    echo "Fruta: " . $_SESSION["fruta"] . "\n";
    echo "\n";

    // Destruyendo la Sesión
    echo "Destruyendo la sesión ...\n";
    session_destroy(); 
?>