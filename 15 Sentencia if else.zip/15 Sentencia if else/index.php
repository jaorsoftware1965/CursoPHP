<?php
    // -------------------------------------
    // Curso de Php
    // Clase 15 Sentenca if else
    // -------------------------------------

    // La Sentencia if es la sentencia clásica de control
    // de flujo de un programa.

    // Se evalua una condicíón y se ejecutan instrucciones
    // dependiendo de si el resultado es falso o verdadero

    // if (condicion)
    //    statement true


    // if (condicion)
    //    statement true
    // else
    //    statement false

    // if (condicion)
    //    statement true
    // elseif (condicion 2)
    //    statement true
    // else
    //    statement false 
    
    echo "Sentencia de control de flujo if else elseif <br>";
    echo "<br>";

    // Declaramos una variable de cantidad
    $cantidad = 32;

    // Verificamos si la cantidad es mayor de 10
    if ($cantidad > 10) 
    {
        // Disminuimos en 2 el precio
        echo "a) $cantidad es mayor que 10";
        echo "<br>";        
    }
    // a

    // Cambio de Linea
    echo "Termina primer if<br>";
    echo "<br>";
    
    $cantidad = 32;
    if ($cantidad > 10) 
    {
        echo "b) $cantidad si es mayor que 10";
        echo "<br>";        
    }
    else
    {
        echo "c) $cantidad no es mayor que 10";
        echo "<br>";        
    }
    // b

    // Cambio de Linea
    echo "Termina segundo if<br>";
    echo "<br>";

    $cantidad = 32;
    if ($cantidad < 10) 
    {
        echo "d) $cantidad es menor que 10";
        echo "<br>";        
    }    
    elseif ($cantidad < 15)
    {
        echo "f) $cantidad es menor que 15";
        echo "<br>";        
    }
    else
    {
        echo "g) $cantidad no es menor que 10";
        echo "<br>";        
        echo "h) $cantidad no es menor que 15";
        echo "<br>";                
    }
    // Ninguno
    echo "Termina tercer if<br>";
    echo "<br>";    
?>

