<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 36 Polimorfismo
    // -------------------------------------------


        
    echo "Polimorfismo\n\n";

    // Definimos una clase
    class Latino
    {
        // Properties
        protected  $nombre;
        protected  $lengua;

        // Constructor
        function __construct ()
        {
           $this->nombre  = "Juan";
           $this->lengua = "Español";
        }

        // Metodos

        public function getNombre() 
        {
            // coloca el nombre
            return $this->nombre;
        }
        
        public function getLengua() 
        {
            // coloca el nombre
            return $this->lengua;
        }

        public function saludar() 
        {
            // coloca el nombre
            echo "Hola\n";
        }        
    }

    // Herencia
    class Ingles extends Latino 
    {   
        // Constructor
        function __construct ()
        {           
           $this->nombre = "Jhon";
           $this->lengua = "Ingles";
        }

        public function saludar() 
        {
            // coloca el nombre
            echo "Hello\n";
        }
        
    }

    // Creamos un objeto
    $oPersona = new Latino();

    // Desplegamos el Nombre Completo
    echo "Nombre del Latino:";
    echo $oPersona->getNombre();
    echo "\n";
    echo "Lengua del Latino:";
    echo $oPersona->getLengua();
    echo "\n";
    echo "Saludo del Latino:";
    $oPersona->saludar();
    echo "\n";
    
    // Creamos un objeto
    $oPersona2 = new Ingles();

    // Desplegamos el Nombre Completo
    echo "Nombre del Ingles:";
    echo $oPersona2->getNombre();
    echo "\n";
    echo "Lengua del Ingles:";
    echo $oPersona2->getLengua();
    echo "\n";
    echo "Saludo del Ingles:";
    $oPersona2->saludar();
    echo "\n";

?>