<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 45 Funciones CallBack
    // -------------------------------------------

    // Una función de devolución de llamada (a menudo denominada simplemente 
    // "devolución de llamada") es una función que se pasa como argumento a otra 
    // función.
    // Cualquier función existente se puede utilizar como función de devolución 
    // de llamada. Para usar una función como función de devolución de llamada, 
    // pase una cadena que contenga el nombre de la función como argumento de otra 
    // función.

    // Función CallBack
    // Devuelve la longitud de una cadena
    function my_callback($item) 
    {
        // Retorna la longitud de item
        return strlen($item);
    }
    
    // Declara un arreglo de String
    $frutas = ["manzana", "pera", "fresa", "uva"];
    
    // Obtiene la longitud de cada elemento
    // Usando la función callback con array_map
    $longitudes = array_map("my_callback", $frutas);

    // Imprime lo devuelto
    echo "Las longitudes de cada una de las frutas del siguiente arreglo:\n";
    print_r($frutas);
    echo "son:\n";
    print_r($longitudes);

    // Funciones Callback en Funciones de Usuario
    // Las funciones y métodos definidos por el usuario también pueden tomar 
    // funciones callback como argumentos. 
    // Para usar funciones callback dentro de una función o método 
    // definido por el usuario, llámelo agregando paréntesis a la variable 
    // y pase argumentos como con las funciones normales.

    // Funcion que agrega sçimbolo de exclamación
    function fnAgregaExclamacion($str) 
    {
        // Agrega el símbolo
        return "¡".$str . "! ";
    }
    
    // Función que agrega símbolo de Pregunta
    function fnAgregaPregunta($str) 
    {
        // Agrega el símbolo
        return "¿". $str . "?";
    }
    
    // Función que recibe la función callback
    // El primer parámetro es el string
    // En el segundo recibe el nombre de la Funcion
    function printFormatted($str, $fnCallBack) 
    {
        // Llamando a la función CallBack con la cadena
        echo $fnCallBack($str);
        echo "\n";
    }
      
    // Pass "exclaim" and "ask" as callback functions to printFormatted()
    printFormatted("Hola a todos", "fnAgregaExclamacion");
    printFormatted("Quien anda ahi", "fnAgregaPregunta");
?>