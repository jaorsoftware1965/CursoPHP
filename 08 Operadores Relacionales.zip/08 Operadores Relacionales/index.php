<?php
// -------------------------------------
// Curso de Php
// Clase 08 Operadores de Comparación
// -------------------------------------

// Los operadores de Comparación tambien conocidos como relacionales
// son los conocidos ya en las Matemáticas Tradicionales.

// Se utilizan para comparar, por eso se llaman de comparación; para
// determinar la relación de un operando con respecto a otro, por eso
// se llaman tambien relacionales.

// A continuación veremos los operadores relacionales de PHP, los cuales
// solo devuelven 2 valores posibles: true o false.

// Operador ==    5 == 9  falso   7 == 7 Verdadero
// Este operador se utiliza para verificar si 2 operandos son iguales

// Operador !=    5 != 9  Verdadero   7 != 7  Falso
// Este operador se utiliza para verificar si 2 operandos son distintos

// Operador >     5 > 9   Falso      15 > 9   Verdadero
// Este operador se utiliza para comparar si un operando es mayor que
// otro operando

// Operador >=    5 >= 9  Falso     15 >= 9   Verdadero 
// Este operador se utiliza para comparar si un operando es mayor 
// o igual que otro

// Operando <     5 < 9  Verdadero    15 < 9   Falso
// Este operador se utiliza para comparar si un operando es menor que
// otro operando

// Operando <=   
// Este operados se utiliza para comparar si un operando es menor o
// igual que otro operando


// Operando === "Idéntico"
// Verifica que los operandos sean iguales en valor y del mismo tipo

// Operando !== "No es identico"
// Verifica que los operandos sean distintos en valor y tipo

    // Declaración de variables
    $x = 10;
    $y =  5;

    // Comparando
    echo "Operadores de Comparación o Relacionales <br>";
    echo "<br>";
    
    echo "El valor de \$x:".$x;
    echo "<br>";
    echo "El valor de \$y:".$y;
    echo "<br>";
    echo "<br>";

    echo "a>";
    echo "\$x == \$y:";
    echo "[".($x == $y)."]";  
    echo "<br>";  
    echo var_dump($x == $y);    
    echo "<br>";
    echo "<br>";
    
    echo "b>";
    echo "\$x != \$y:";
    echo "[".($x != $y)."]";    
    echo "<br>";
    echo var_dump($x != $y);    
    echo "<br>";
    echo "<br>";

    echo "c>";
    echo "\$x > \$y:";
    echo "[". ($x > $y)."]";    
    echo "<br>";
    echo var_dump($x > $y);    
    echo "<br>";
    echo "<br>";

    echo "d>";
    echo "\$x >= \$y:";
    echo "[". ($x >= $y)."]";    
    echo "<br>";
    echo var_dump($x >= $y);    
    echo "<br>";
    echo "<br>";

    echo "e>";
    echo "\$x < \$y:";
    echo "[". ($x < $y)."]";    
    echo "<br>";
    echo var_dump($x < $y);    
    echo "<br>";
    echo "<br>";

    echo "f>";
    echo "\$x <= \$y:";
    echo "[". ($x <= $y)."]";    
    echo "<br>";
    echo var_dump($x <= $y);    
    echo "<br>";
    echo "<br>";

    echo "g>";    
    echo "<br>";
    echo "'100' == 100".var_dump("100" == 100);    
    echo "<br>";

    echo "'100' === 100".var_dump("100" === 100);    
    echo "<br>";
    echo "<br>";

    echo "h>";  
    echo "<br>";  
    echo "100 == 100.0".var_dump(100 == 100.0);    
    echo "<br>";

    echo "100 === 100.00".var_dump(100 === 100.0);    
    echo "<br>";
    echo "<br>";


    echo "i>";   
    echo "<br>"; 
    echo "'100' !== 100.0".var_dump('100' !== 100);// true
    echo "<br>";

    echo "100 !== 100.00".var_dump(100 !== 100.0);// true
    echo "<br>";

    echo "100 !== 100".var_dump(100 !== 100);// false
    echo "<br>";
    echo "<br>";

?>