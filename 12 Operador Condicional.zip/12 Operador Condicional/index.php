<?php
    // -------------------------------------
    // Curso de Php
    // Clase 12 Operador Condicional o Ternario
    // -------------------------------------

    // Este operador asigna un valor dependiendo de una condición
    // ?:
    // $x = expr1 ? expr2 : expr3

    
    
    // Declaración de variables
    echo "Operador Condicional <br><br>";
   
    // Declaramos variables
    $x = 10;
    $y = 11;
    
     
    $a = !($y > 19  && $x > $y) ?   // Condición
         $x * 2  :   // Esto lo que va devolver si es verdad
         $y + 2  ;   // Esto lo que va devolver si es falso

    // Se imprime a
    echo $a;
    

    //echo "a) \$resultado :".$resultado; // 
    //echo "<br><br>";


    // $resultado = $x > 13 ? "Es verdad que $x < 13" :
    //                        "Es falso  que $x < 13";
    // echo "b) \$resultado :".$resultado;  
    // echo "<br><br>";

    // $resultado = $y < $x ? "$y < $x" : "$y >= $x";
    // echo "c) \$resultado :".$resultado; 
    // echo "<br><br>";

    // $resultado = $y < $x ? $y * 2 : $x * 2;
    // echo "d) \$resultado :".$resultado; 
    // echo "<br>";    
    // echo "<br><br>";                               
    
?>
