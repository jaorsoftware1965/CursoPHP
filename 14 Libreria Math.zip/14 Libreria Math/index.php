<?php
    // -------------------------------------
    // Curso de Php
    // Clase 14 Libreria Math
    // -------------------------------------

    // Hemos visto funciones para cadenas.
    // Ahora veremos funciones Matemáticas

    // Declaración de variables
    echo "Funciones Matemáticas Librería MATH <br><br>";
    
    // Preparo la variable x
    echo("El valor de PI:");
    echo "<br>";

    echo pi(); 
    echo "<br>";
    echo "<br>";

    echo("El valor maximo de 0,150,30,20,-8,-200:");
    echo "<br>";
    echo(max(0, 150, 30, 20, -8, -200));  // returns 150
    echo "<br>";
    echo "<br>";

    echo("El valor mínimo de 0,150,30,20,-8,-200:");
    echo "<br>";
    echo(min(0, 150, 30, 20, -8, 200,234,8990));  // returns -200
    echo "<br>";
    echo "<br>";

    echo("El valor absoluto de -6.7:");
    echo "<br>";
    echo(abs(-6.7));  // returns 6.7
    echo "<br>";
    echo "<br>";

    echo("La Raiz Cuadrada de 81:");
    echo "<br>";
    echo(sqrt(81));
    echo "<br>";
    echo "<br>";

    echo("Redondeando 1.60:");
    echo "<br>";
    echo(ROUND(1.60));  
    echo "<br>";
    echo "<br>";

    echo("Redondeando 2.50  :");
    echo "<br>";
    echo(round(2.50));  // returns 0
    echo "<br>";
    echo "<br>";

    echo("Redondeando 2.49  :");
    echo "<br>";
    echo(round(2.49));  // returns 0
    echo "<br>";
    echo "<br>";

    echo("Numero aleatorio sin rango:");
    echo "<br>";
    echo(rand());
    echo "<br>";    
    echo "<br>";    

    echo("Numero aleatorio entre 15 y 20:");
    echo "<br>";

    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo(rand(15, 20));
    echo "<br>";
    echo "<br>";

    echo bindec('110011');
    echo "<br>";
    echo ceil(4.3);    // 5
    echo "<br>";
    echo ceil(9.999);  // 10
    echo "<br>";
    echo ceil(-3.14);  // -3
    echo "<br>";
?>