<?php
    // -------------------------------------------
    // Curso de Php
    // Clase 43 Iterables
    // -------------------------------------------

    // Un iterable es cualquier valor que se puede recorrer con un bucle foreach().
    // El pseudotipo iterable se introdujo en PHP 7.1 y puede usarse como un tipo 
    // de datos para argumentos de funciones y valores de retorno de funciones.

    // La palabra clave "iterable" se puede utilizar como tipo de datos de un argumento 
    // de función o como tipo de retorno de una función. Ejemplo

    // Declaramos una función con un parámetro iterable
    function imprimeIterable(iterable $objetoIterable) 
    {
        // Mensaje
        echo "Elementos en el objeto iterable:\n";
        // Ciclo foreach
        foreach($objetoIterable as $elemento) 
        {
            // Se despliega el valor de cada elemento
            echo $elemento;
            echo "\n";
        }
    }

    // Probamos con un arreglo
    $arr = ["a", "b", "c"];

    // Llamamos a la función
    imprimeIterable($arr);

    // Declaramos una cadena
    $cadena ="JaorSoftware";

    // No considera a la cadena iterable
    // imprimeIterable($cadena);

    // Función para obtener un iterable
    function getIterable():iterable 
    {
        // Retorna el arreglo
        return [1, 2, 5, a, 3.1416, null, NaN];
    }
    
    // Obtiene el arreglo
    $miIterable = getIterable();

    // Llama de nuevo a la función
    imprimeIterable($miIterable);
    echo "\n";

    // Cualquier objeto que implemente la interfaz Iterator se puede 
    // usar como argumento de una función que requiere un iterable.
    // Un iterador contiene una lista de elementos y proporciona métodos 
    // para recorrerlos. 
    // Mantiene un puntero a uno de los elementos de la lista. Cada elemento 
    // de la lista debe tener una clave que se puede utilizar para encontrar 
    // el elemento.

    // Un iterador debe tener estos métodos:

    // current() Devuelve el elemento al que apunta actualmente el puntero. 
    //           Puede ser cualquier tipo de dato
    // key()     Devuelve la clave asociada con el elemento actual en la lista. 
    //           Solo puede ser un número entero, flotante, booleano o cadena
    // next()    Mueve el puntero al siguiente elemento de la lista
    // rewind()  Mueve el puntero al primer elemento de la lista
    // valid()   Si el puntero interno no apunta a ningún elemento (por ejemplo, 
    //           si se llamó a next() al final de la lista), debería devolver 
    //           falso. Devuelve verdadero en cualquier otro caso.

    // Create an Iterator
    class claseIterador implements Iterator 
    {
        private $items = [];
        private $pointer = 0;
    
        public function __construct($items) 
        {
            // array_values() makes sure that the keys are numbers
            $this->items = array_values($items);
        }
    
        public function current() 
        {
            return $this->items[$this->pointer];
        }
    
        public function key() 
        {
            return $this->pointer;
        }
    
        public function next() 
        {
            $this->pointer++;
        }
    
        public function rewind() 
        {
            $this->pointer = 0;
        }
    
        public function valid() 
        {
            // count() indicates how many items are in the list
            return $this->pointer < count($this->items);
        }
    }
        
    // Use the iterator as an iterable
    $iterator = new claseIterador(["VB", "python", "c#"]);
    imprimeIterable($iterator);   
?>